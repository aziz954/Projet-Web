<?PHP
include "../entities/login.php";
include "../core/loginC.php";

if (isset($_GET['id']) and isset($_GET['usertype']) and isset($_GET['username']) and isset($_GET['email']) and isset($_GET['password'])){
    $target_file = $_FILES["photo"];

$log1=new log($_GET['id'],$_GET['usertype'],$_GET['username'],$_GET['email'],$_GET['password'],null);

$log1C=new logC();
$log1C->ajouter($log1, $target_file);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery has been Added', 'unread', CURRENT_TIMESTAMP, 'register.php');";
    $db = config::getConnexion();

    try{
      
                $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: register.php');
  
}
else{
  
    echo "not done";
            $_SESSION['status'] =  "Delivery is Not Added";
            header('Location: register.php');
}
//*/

?>
