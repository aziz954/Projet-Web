<?PHP
include "../config.php";
class logC {
function afficher ($log){
		echo "id: ".$log->getid()."<br>";
		echo "usertype: ".$log->getusertype()."<br>";
		echo "username: ".$log->getusername()."<br>";
		echo "email: ".$log->getemail()."<br>";
		echo "password".$log->passwowrd()."<br>";
				echo "image".$log->image()."<br>";

	}
	
	function ajouter($log, $file){
 	// Get image name
   $target_dir = "uploads/";
        $target_file = $target_dir . basename($file["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        move_uploaded_file($file["tmp_name"], $target_file);
		$sql="insert into register (id,usertype,username,email,password,image)
 values (:id, :usertype,:username,:email,:password,:image)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$log->getid();
        $usertype=$log->getusertype();
        $username=$log->getusername();
        $email=$log->getemail();
        $password=$log->getpassword();
        $image=$log->getimage();
		$req->bindValue(':id',$id);
		$req->bindValue(':usertype',$usertype);
		$req->bindValue(':username',$username);
		$req->bindValue(':email',$email);
		$req->bindValue(':password',$password);
		$req->bindValue(':image',$target_file);       


            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherlog(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From register";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerlog($id){
		$sql="DELETE FROM register where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierlog($log,$id){
		$sql="UPDATE register SET id=:id, usertype=:usertype,username=:username,email=:email,password=:password WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$log->getid();
        $usertype=$log->getusertype();
        $username=$log->getusername();
        $email=$log->getemail();
        $password=$log->getpassword();
		$datas = array(':id'=>$id, ':usertype'=>$usertype, ':username'=>$username,':email'=>$email,':password'=>$password);
		$req->bindValue(':id',$id);
		$req->bindValue(':usertype',$usertype);
		$req->bindValue(':username',$username);
		$req->bindValue(':email',$email);
		$req->bindValue(':password',$password);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlog($id){
		$sql="SELECT * from register where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListelog($id){
		$sql="SELECT * from register where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tridesc(){
		$sql="SELECT * from register ORDER BY id DESC";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tri(){
		$sql="SELECT * from register ORDER BY id ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
