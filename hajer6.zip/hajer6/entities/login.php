<?php
/**
 * 
 */
 

class log
{
	
	private $id;
	private $usertype;
	private $username;
	private $email;
	private $password;
private $image;
	public function getid(){
		return $this->id;

	}
	public function getusertype()
	{
		return $this->usertype;

	}
	public function getusername()
	{
		return $this->username;

	}
	public function getemail()
	{
		return $this->email;
	}
	public function getpassword()
	{
		return $this->password;
	}
	public function getimage()
	{
		return $this->image;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	public function setusertype($usertype)
	{

		$this->usertype=$usertype;
	}
		public function setusername($username)
	{

		$this->username=$username;
	}
	public function setemail($email)
	{

		$this->email=$email;
	}
	public function setpassword($hpassword)
	{

		$this->password=$password;
	}
public function setimage($image)
	{

		$this->image=$image;
	}

	public function construct()
	{
		$this->id=0;
		$this->usertype="";
		$this->username="";
		$this->email="";
		$this->password="";
				$this->image="";



	}
	public function __construct($id,$usertype,$username,$email,$password,$image)
	{

		$this->id=$id;
		$this->usertype=$usertype;
		$this->username=$username;
		$this->email=$email;
		$this->password=$password;
		$this->image=$image;
	}
	
}

?>


