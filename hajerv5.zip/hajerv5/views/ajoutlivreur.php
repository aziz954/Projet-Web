<?PHP
include "../entities/livreur.php";
include "../core/livreurC.php";

if (isset($_GET['nom']) and isset($_GET['prenom']) and isset($_GET['id']) and isset($_GET['idliv']) ){
$livr1=new livr($_GET['nom'],$_GET['prenom'],$_GET['id'],$_GET['idliv']);

$livr1C=new livrC();
$livr1C->ajouter($livr1);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery2 has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionlivreur.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionlivreur.php');
    
}
else{
    
      echo "not done";
            $_SESSION['status'] =  "Delivery is Not Added";
            header('Location: gestionlivreur.php');
}
//*/

?>