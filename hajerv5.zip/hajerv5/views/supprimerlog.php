<?PHP
include "../core/loginC.php";
$logC=new logC();
if (isset($_POST["id"])){
  $logC->supprimerlog($_POST["id"]);
    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A User/Admin has been Deleted', 'unread', CURRENT_TIMESTAMP, 'register.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: register.php');
}

?>