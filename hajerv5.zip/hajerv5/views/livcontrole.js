function validate(){
  var id = document.getElementById("id").value;
  var ref = document.getElementById("ref").value;
  var adr = document.getElementById("adr").value;
  var time = document.getElementById("time").value;
  var date = document.getElementById("date").value;
  var error_message = document.getElementById("error_message");
  
  error_message.style.padding = "10px";
  
  var text;
  =
  if(adr < 10){
    text = "Please Enter Correct adresse";
    error_message.innerHTML = text;
    return false;
  }
  if(isNaN(id) || id.length != 8){
    text = "Please Enter valid Phone Number";
    error_message.innerHTML = text;
    return false;
  }
  if(email.indexOf("@") == -1 || email.length < 6){
    text = "Please Enter valid Email";
    error_message.innerHTML = text;
    return false;
  }

  alert("Form Submitted Successfully!");
  return true;
}