<?PHP
include "../config.php";
class livrC {
function afficher ($livr){
		echo "nom: ".$livr->getnom()."<br>";
		echo "prenom: ".$livr->getprenom()."<br>";
		echo "id: ".$livr->getid()."<br>";
		echo "idliv: ".$livr->getidliv()."<br>";
	}
	
	function ajouter($livr){
		$sql="insert into livreur (nom,prenom,id,idliv)
 values (:nom, :prenom,:id,:idliv)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $nom=$livr->getnom();
        $prenom=$livr->getprenom();
        $id=$livr->getid();
        $idliv=$livr->getidliv();
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':id',$id);
		$req->bindValue(':idliv',$idliv);		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherlivr(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From livreur";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerlivr($id){
		$sql="DELETE FROM livreur where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierlivr($livr,$id){
		$sql="UPDATE livreur SET nom=:nom, prenom=:prenom,id=:id,idliv=:idliv WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$nom=$livr->getnom();
        $prenom=$livr->getprenom();
        $id=$livr->getid();
        $idliv=$livr->getidliv();
		$datas = array(':nom'=>$nom, ':prenom'=>$prenom, ':id'=>$id,':idliv'=>$idliv);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':id',$id);
		$req->bindValue(':idliv',$idliv);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererlivr($id){
		$sql="SELECT * from livreur where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListelivr($id){
		$sql="SELECT * from livreur where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tridesc(){
		$sql="SELECT * from livreur ORDER BY id DESC";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tri(){
		$sql="SELECT * from livreur ORDER BY id ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
