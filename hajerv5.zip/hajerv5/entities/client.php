<?php
/**
 * 
 */
 

class client
{
	

	private $nom;
	private $prenom;
    private $adresse;
    private $num;
    private $id;

	
	public function getnom()
	{
		return $this->nom;

	}
	public function getprenom()
	{
		return $this->prenom;
	}
	public function getadresse()
	{
		return $this->adresse;
    }
    public function getnum()
	{
		return $this->num;
	}
	public function getid()
	{
		return $this->id;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	
	public function setnom($nom)
	{

		$this->nom=$nom;
	}
	public function setprenom($prenom)
	{

		$this->prenom=$prenom;
	}
	public function setadresse($adresse)
	{

		$this->adresse=$adresse;
    }
    public function setnum($num)
	{

		$this->num=$num;
	}
	public function construct()
	{
		
		$this->nom="";
        $this->prenom="";
        $this->adresse="";
        $this->num=0;
        $this->id=0;


	}
	public function __construct($nom,$prenom,$adresse,$num,$id)
	{

		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->adresse=$adresse;
		$this->num=$num;
		$this->id=$id;
	}
	
}

?>


