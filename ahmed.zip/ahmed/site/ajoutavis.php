<?PHP
include "../entities/Avis.php";
include "../core/avisC.php";

if (isset($_POST['id_client']) and isset($_POST['type']) and isset($_POST['avis'])  ){

$avis1=new Avis($_POST['id_client'],$_POST['type'],$_POST['avis']);

$avis1C=new avisC();
$avis1C->ajouterAvis($avis1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'Avis has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: afficheravisf.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Facture is Not Added";
            header('Location: contact.php');
}
//*/

?>