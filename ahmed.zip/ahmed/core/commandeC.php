
<?PHP
include "C:/Users/HP/Desktop/nouveau/htdocs/admin/config.php";
class CommandeC {
function affichercommande ($commande){
		echo "ID ".$commande->getid()."<br>";
		echo "ID DU CLIENT: ".$commande->getid_cl()."<br>";
		echo "Quantité: ".$commande->getq()."<br>";

	}
	
	function ajoutercommande($commande){
		$sql="insert into commande (id,id_cl,q)
 values (:id, :id_cl,:q)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$commande->getid();
        $id_cl=$commande->getid_cl();
        $q=$commande->getq();
 
		$req->bindValue(':id',$id);
		$req->bindValue(':id_cl',$id_cl);
		$req->bindValue(':q',$q);

		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function affichercommandes(){
		//$sql="SElECT * From commande e inner join formationphp.commande a on e.id= a.id";
		$sql="SElECT * From commande";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimercommande($id){
		$sql="DELETE FROM commande where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifiercommande($commande,$id){
		$sql="UPDATE commande SET id=:id, id_cl=:id_cl,q=:q WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$idn=$commande->getid();
        $id_cl=$commande->getid_cl();
        $q=$commande->getq();
		$datas = array(':id'=>$id, ':id_cl'=>$id_cl,':q'=>$q);
		$req->bindValue(':id',$id);
		$req->bindValue(':id_cl',$id_cl);
		$req->bindValue(':q',$q);

		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recuperercommande($id){
		$sql="SELECT * from commande where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListecommandes($tarif){
		$sql="SELECT * from commande where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>