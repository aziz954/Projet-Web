<?PHP
include "../config.php";
class factureC {
function afficher ($facture){
		echo "id: ".$facture->getid()."<br>";
		echo "mont: ".$facture->getmont()."<br>";
		echo "id_com: ".$facture->getid_com()."<br>";
		echo "id_cl: ".$facture->getid_cl()."<br>";
		echo "datef".$facture->getdatef()."<br>";
	}
	
	function ajouter($facture){
		$sql="insert into facture (id,mont,id_com,id_cl,datef)
 values (:id, :mont,:id_com,:id_cl,:datef)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$facture->getid();
        $mont=$facture->getmont();
        $id_com=$facture->getid_com();
        $id_cl=$facture->getid_cl();
        $datef=$facture->getdatef();
		$req->bindValue(':id',$id);
		$req->bindValue(':mont',$mont);
		$req->bindValue(':id_com',$id_com);
		$req->bindValue(':id_cl',$id_cl);
		$req->bindValue(':datef',$datef);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherfacture(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From facture";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerfacture($id){
		$sql="DELETE FROM facture where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierfacture($facture,$id){
		$sql="UPdate facture SET id=:id, mont=:mont,id_com=:id_com,id_cl=:id_cl,datef=:datef WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$facture->getid();
        $mont=$facture->getmont();
        $id_com=$facture->getid_com();
        $id_cl=$facture->getid_cl();
        $datef=$facture->getdatef();
		$datas = array(':id'=>$id, ':mont'=>$mont, ':id_com'=>$id_com,':id_cl'=>$id_cl,':datef'=>$datef);
		$req->bindValue(':id',$id);
		$req->bindValue(':mont',$mont);
		$req->bindValue(':id_com',$id_com);
		$req->bindValue(':id_cl',$id_cl);
		$req->bindValue(':datef',$datef);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererfacture($id){
		$sql="SELECT * from facture where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListefacture($id){
		$sql="SELECT * from facture where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
