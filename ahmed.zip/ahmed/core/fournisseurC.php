<?PHP
include "../config.php";
class fournisseurC {
function afficherFournisseurs($fournisseur){
		echo "id ".$fournisseur->getid()."<br>";
		echo "nom: ".$fournisseur->getnom()."<br>";
		echo "prénom: ".$fournisseur->getprenom()."<br>";
		echo "date: ".$fournisseur->getdate()."<br>";
		echo "tache: ".$fournisseur->gettache()."<br>";
	}
	function ajouterFournisseur($fournisseur){
		$sql="insert into fournisseur (id,nom,prenom,date,tache) values (:id, :nom,:prenom,:date,:tache)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $id=$fournisseur->getid();
        $nom=$fournisseur->getNom();
        $prenom=$fournisseur->getPrenom();
        $date=$fournisseur->getDate();
        $tache=$fournisseur->getTache();
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':date',$date);
		$req->bindValue(':tache',$tache);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherFournisseur(){
		$sql="SElECT * From fournisseur";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerFournisseur($id){
		$sql="DELETE FROM fournisseur where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierFournisseur($fournisseur,$id){
		$sql="UPDATE fournisseur SET id=:idd, nom=:nom,prenom=:prenom,date=:date,tache=:tache WHERE id=:id";
		
		$db = config::getConnexion();
try{		
        $req=$db->prepare($sql);
		$idd=$fournisseur->getid();
        $nom=$fournisseur->getnom();
        $prenom=$fournisseur->getprenom();
        $date=$fournisseur->getdate();
        $tache=$fournisseur->gettache();
		$datas = array(':idd'=>$idd, ':id'=>$id, ':nom'=>$nom,':prenom'=>$prenom,':date'=>$date,':tache'=>$tache);
		$req->bindValue(':idd',$idd);
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':date',$date);
		$req->bindValue(':tache',$tache);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererFournisseur($id){
		$sql="SELECT * from fournisseur where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
function tridesc(){
		$sql="SELECT * from fournisseur ORDER BY id DESC";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tri(){
		$sql="SELECT * from fournisseur ORDER BY id ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	}