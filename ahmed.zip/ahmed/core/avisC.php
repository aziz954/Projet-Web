<?PHP
include "../config.php";
class avisC {
function afficherAvi ($avis){
		echo "id_client: ".$avis->getid_client()."<br>";
		echo "type: ".$avis->gettype()."<br>";
		echo "avis: ".$avis->getavis()."<br>";
	}
	
	function ajouterAvis($avis){
		$sql="insert into avis (id_client,type,avis) values (:id_client, :type,:avis)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
		
        $id_client=$avis->getid_client();
        $type=$avis->gettype();
        $avis=$avis->getavis();
      
		$req->bindValue(':id_client',$id_client);
		$req->bindValue(':type',$type);
		$req->bindValue(':avis',$avis);
	
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherAvis(){
		$sql="SElECT * From avis";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerAvis($id_client){
		$sql="DELETE FROM avis where id_client= :id_client";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id_client',$id_client);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierAvis($avis,$id_client){
		$sql="UPdate avis SET id_client=:id_client, type=:type,avis=:avis WHERE id_client=:id_client";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id_client=$avis->getId_client();
        $type=$avis->getType();
        $avis=$avis->getAvis();
       
		$datas = array(':id_client'=>$id_client, ':type'=>$type, ':avis'=>$avis);
		$req->bindValue(':id_client',$id_client);
		$req->bindValue(':type',$type);
		$req->bindValue(':avis',$avis);
	
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererAvis($id_client){
		$sql="SELECT * from avis where id_client=$id_client";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	}