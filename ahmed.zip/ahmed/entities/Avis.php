<?PHP
class Avis{
	private $id_client;
	private $type;
	private $avis ; 
	
	function __construct($id_client,$type,$avis){
		$this->id_client=$id_client;
		$this->type=$type;
		$this->avis=$avis;

	}
	function getId_client(){
		return $this->id_client;
	}
	
	function getType(){
		return $this->type;
	}
	function setType($type){
		$this->type=$type;
	}
	function getAvis(){
		return $this->avis;
	}
	function setAvis($avis){
		$this->avis=$avis;
	}
	
}

?>