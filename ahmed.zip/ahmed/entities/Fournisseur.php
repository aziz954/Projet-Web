<?PHP
class fournisseur{
	private $id;
	private $nom;
	private $prenom;
	private $date;
	private $tache;

	
	function __construct($id,$nom,$prenom,$date,$tache){
		$this->id=$id;
		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->date=$date; 
		$this->tache=$tache;

	}
	function getId(){
		return $this->id;
	}
	function setNOM($nom){
		$this->nom=$nom;
	}
	function getNom(){
		return $this->nom;
	}
	function setPrenom($prenom){
		$this->prenom=$prenom;
	}
	function getDate(){
		return $this->date;
	}
	function setDate($date){
		$this->date=$date;
	}
	function getTache(){
		return $this->tache;
	}
	function setTache($tache){
		$this->tache=$tache;
	}
	function getPrenom(){
		return $this->prenom;
	}
	
}

?>