<?PHP
class Facture{
	private $id;
	private $mont;
    private $id_com;
    private $id_cl;
    private $datef;
    
	function __construct($id,$mont,$id_com,$id_cl,$datef){
		$this->id=$id;
		$this->mont=$mont;
        $this->id_com=$id_com;
        $this->id_cl=$id_cl;
        $this->datef=$datef;
    }
	
	function getid(){
		return $this->id;
	}
	function getmont(){
		return $this->mont;
	}
	function getid_com(){
		return $this->id_com;
    }
    
    function getid_cl(){
		return $this->id_cl;
    }
    
    function getdatef(){
		return $this->datef;
	}



        function setid($id){
	       $this->id=$id;
	}

	function setmont($mont){
		$this->mont=$mont;
	}
	function setid_com($id_com){
		$this->id_com;
	}
	function setid_cl($id_cl){
		$this->id_cl;
    }
    
    function setdatef($datef){
		$this->datef;
	}
}


?>