<?PHP
class Commande{
	private $id;
	private $id_cl;
    private $q;
    
	function __construct($id,$id_cl,$q){
		$this->id=$id;
		$this->id_cl=$id_cl;
		$this->q=$q;
    }
	
	function getid(){
		return $this->id;
	}
	function getid_cl(){
		return $this->id_cl;
	}
	function getq(){
		return $this->q;
	}



        function setid($id){
	       $this->id=$id;
	}

	function setid_cl($id_cl){
		$this->id_cl=$id_cl;
	}
	function setq($q){
		$this->q;
	}
	
}


?>