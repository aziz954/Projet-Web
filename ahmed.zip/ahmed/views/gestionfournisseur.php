<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/fournisseurC.php";
$fournisseur1C=new fournisseurC();
$listefournisseur=$fournisseur1C->afficherFournisseur();
?>
<script language="javascript"type="text/javascript" src="livcontrole.js"></script>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">f fournisseur</h5> 
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      </div>
      <form action="ajoutfournisseur.php" method="GET">

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id" required="required" >

            </div>
            <div class="form-group">
                <label>NOM</label>
                <input type="text" name="nom" class="form-control" placeholder="Enter Nom" required="required">
            </div>
            <div class="form-group">
                <label>PRENOM</label>
                <input type="text" name="prenom" class="form-control" placeholder="Enter Prenom" required="required">
            </div>
            <div class="form-group">
                <label>DATE</label>
                <input type="date" name="date" class="form-control" placeholder="Enter la Date" required="required">
            </div>
               <div class="form-group">
                <label>TACHE</label>
                 <select name="tache" required="required" class="form-control" > 

                  <option value="medicaments ">medicaments</option>
                  <option value="fournitures ">fournitures </option>
                                            </select>
                
            </div>
        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">fournisseur Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add fournisseur Profile 
            </button> 
             <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">Print</button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
    </h6>
  </div>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> Nom </th>
            <th> Prenom </th>
            <th>Date</th>
            <th>Tache</th>
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
     <?php
foreach($listefournisseur as $row){

 
  
    ?>
    <tr>
      <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['nom']; ?> </td>
      <td><?php echo $row['prenom']; ?> </td>
      <td><?php echo $row['date']; ?> </td>
      <td><?php echo $row['tache']; ?> </td>
      <td>
       
          <input type="hidden" name ="edit_id3" value="<?php echo $row['id']; ?>">

     <a href="modifierfournisseur.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerfournisseur.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }

     ?>
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- Donut Chart -->
            <div class="col-xl-4 col-lg-5">
              
                <!-- Card Header - Dropdown -->
                 <?php  
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $query = "SELECT tache, count(*) as nom FROM fournisseur GROUP BY tache";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Stat des fournisseurs</title>  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['tache', 'nom'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["tache"]."', ".$row["nom"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage ',  
                      //is3D:true,  
                      pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>  
      </head>  
      <body>  
           <br /><br />  
           <div style="width:900px;">  
                <h1 align="center">STAT des Produits</h1>  
                <br />  
                <div id="piechart" style="width: 900px; height: 500px;"></div>  
           </div>  
      </body>  
 </html>  
                
             
            </div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>