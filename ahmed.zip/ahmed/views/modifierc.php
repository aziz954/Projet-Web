
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/commande.php";
include "../core/commandeC.php";
if (isset($_GET['id'])){
    $commandeC=new commandeC();
    $result=$commandeC->recuperercommande($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $id_cl=$row['id_cl'];
        $q=$row['q'];
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT DE  </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID">
            </div>
            <div class="form-group">
                <label>Id client</label>
                <input type="text" name="id_cl" value="<?php echo $row['id_cl']; ?>" class="form-control" placeholder="Enter ID CLIENT">
            </div>
            <div class="form-group">
                <label>Quantité</label>
                <input type="text" name="q"  value="<?php echo $row['q']; ?>"class="form-control" placeholder="Enter Quantite">
            </div >
            
            <a href="gestioncom.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $commande=new commande($_POST['id'],$_POST['id_cl'],$_POST['q']);
    $commandeC->modifiercommande($commande,$_POST['edit_id']);


    echo '<meta http-equiv="refresh" content="0; URL=gestioncom.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
