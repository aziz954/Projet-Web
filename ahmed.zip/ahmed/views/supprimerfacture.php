<?PHP
include "../core/factureC.php";
$factureC=new factureC();
if (isset($_POST["id"])){
  $factureC->supprimerfacture($_POST["id"]);
  header('Location: gestionfacture.php');
}

?>