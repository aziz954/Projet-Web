
<?php
session_start();

include "C:/xampp/htdocs/ahmed/views/ajoutavis.php";
//$fournisseur1C=new fournisseurC();
//$listefournisseur=$fournisseur1C->afficherFournisseur();
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <title>Pharma &mdash; </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">


  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <div class="site-wrap">


    <div class="site-navbar py-2">

      <div class="search-wrap">
        <div class="container">
          <a href="#" class="search-close js-search-close"><span class="icon-close2"></span></a>
          <form action="#" method="post">
            <input type="text" class="form-control" placeholder="Search keyword and hit enter...">
          </form>
        </div>
      </div>

      <div class="container">
        <div class="d-flex align-items-center justify-content-between">
          <div class="logo">
            <div class="site-logo">
              <a href="welcome.html" class="js-logo-clone"><img src="images\logo.png" alt=""></a>
            </div>
          </div>
          <div class="main-nav d-none d-lg-block">
            <nav class="site-navigation text-right text-md-center" role="navigation">
              <ul class="site-menu js-clone-nav d-none d-lg-block">
                <li><a href="welcome.html"><H2>Home</H2></a></li>
                <li><a href="shop.html"><H2>Store</H2></a></li>
                <li class="has-children">
                  <a href="#"><H2>Shop</H2></a>
                  <ul class="dropdown">
                    <li><a href="#">Supplements</a></li>
                    <li class="has-children">
                      <a href="shop_by_cat.html">Vitamins</a>
                      <ul class="dropdown">
                        <li><a href="#">Supplements</a></li>
                        <li><a href="#">Vitamins</a></li>
                        <li><a href="#">Diet &amp; Nutrition</a></li>
                        <li><a href="#">Tea &amp; Coffee</a></li>
                      </ul>
                    </li>
                    <li><a href="#">Diet &amp; Nutrition</a></li>
                    <li><a href="#">Tea &amp; Coffee</a></li>

                  </ul>
                </li>
                <li><a href="about.html"><H2>About</H2></a></li>
                <li class="active"><a href="contact.html"><H2>Contact</H2></a></li>
              </ul>
            </nav>
          </div>
          <div class="icons">
            <a href="#" class="icons-btn d-inline-block js-search-open"><span class="icon-search"></span></a>
            <a href="cart.html" class="icons-btn d-inline-block bag">
              <span class="icon-shopping-bag"></span>
              <span class="number">2</span>
            </a>
            <a href="Login_v9\index.html" class="icons-btn d-inline-block user">
              <span class="icon-users"></span></a>
              <a href="admin/login.php" class="icons-btn d-inline-block user">
              <span class="icon-user-md"></span></a>
            <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                class="icon-menu"></span></a>
          </div>
        </div>
      </div>
    </div>

    <div class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0">
            <a href="index.html">Home</a> <span class="mx-2 mb-0">/</span>
            <strong class="text-black">Contact</strong>
          </div>
        </div>
      </div>
    </div>





    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2 class="h3 mb-5 text-black" >Donner Votre Avis</h2>
          </div>


  <!-------------------------------------------------------------------- ajouter avis -------------------------------------------------------------------------->


            <div class="col-md-12">
            <form action="ajoutavis.php" method="POST">
    
                                      <div class="p-3 p-lg-5 border">
               
                                     <div class="form-group row">
                 
                                     <div class="col-md-6">
                   
                                     <label for="c_fname" class="text-black"> ID <span class="text-danger">*</span></label>
                                     <input type="text" class="form-control" id="id_client" name="c_fname" required="required">
                                     </div>
                  
                                      </div>
                                      <div class="form-group row">
                 
                                      </div>
                                                 <div class="form-group row" >
                   <select name="type" required="required" class="controle" > 

                  <option value="services ">livraison</option>
                  <option value="site web ">produits </option>
                   </select><span class="resultat"></span>
                    </div>
                                                  </div>
    
                                      <div class="form-group row">
                                      <div class="col-md-12">
                                      <label for="c_message" class="text-black" >AVIS </label>
                                       <textarea name="c_message"  cols="30" rows="7" class="form-control" required="required"  id="avis"></textarea>
                                       </div>
                                      </div>
                                                <div class="form-group row">
                                                <div class="col-lg-12">
                                                <input type="submit" name="ajouter"  class="btn btn-primary btn-lg btn-block" value="Send Avis">
                                                </div>
                                                 </div>
                                                </div>
               </form>
          
           </div>
          
        </div>
      </div>
    </div>

 <!--------------------------------------------------------/  ---------------------------------------------------------------------------------------------------------------->






    <div class="site-section bg-primary">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h2 class="text-white mb-4">Offices</h2>
          </div>
          
          <div class="col-lg-4">
            <div class="p-4 bg-white mb-3 rounded">
              <span class="d-block text-black h6 text-uppercase">Tunisie</span>
              <p class="mb-0">51, Avenue 10 Décembre 1948 - 1082, C. MAHRAJÈNE TUNIS tn</p>
            </div>
          </div>
       
        </div>
      </div>
      
    </div>


    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

            <div class="block-7">
              <h3 class="footer-heading mb-4">About Us</h3>
              <p>Medline contracts with licensed pharmacies in tunisia, in order to provide you with the lowest possible prices for your medications.</p>
            </div>

          </div>
          <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
            <h3 class="footer-heading mb-4">Quick Links</h3>
            <ul class="list-unstyled">
              <li><a href="#">Supplements</a></li>
              <li><a href="#">Vitamins</a></li>
              <li><a href="#">Diet &amp; Nutrition</a></li>
              <li><a href="#">Tea &amp; Coffee</a></li>
            </ul>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Contact Info</h3>
              <ul class="list-unstyled">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d20675.856973871993!2d10.164850353030369!3d36.8149842931309!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1254d0002dbd45a9%3A0xc48041470ed053fd!2smed.tn!5e0!3m2!1sfr!2stn!4v1586774341999!5m2!1sfr!2stn" width="500" height="350" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
              </ul>
            </div>


          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
          
          </div>

        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>

</body>

</html>