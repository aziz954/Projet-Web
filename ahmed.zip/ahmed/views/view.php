<?php
    
    include("functions.php");

    $id = $_GET['id'];
    $url=$_GET['lien'];

    $query ="UPDATE `notifications` SET `status` = 'read' WHERE `id` = $id;";
    performQuery($query);

?>

<html>
   <head>

<meta http-equiv="refresh" content="0;URL=index.php" />
      </head>
    <body>
      <p>Redirecting to another URL</p>
   </body>
</html>