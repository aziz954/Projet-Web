<?PHP
include "../core/avisC.php";
$avisC=new avisC();
if (isset($_POST["id_client"])){
  $factureC->supprimerAvis($_POST["id_client"]);
  header('Location: afficheravisf.php');
}

?>