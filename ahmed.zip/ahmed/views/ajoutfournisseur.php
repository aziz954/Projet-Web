<?PHP
include "../entities/Fournisseur.php";
include "../core/fournisseurC.php";

if (isset($_GET['id']) and isset($_GET['nom']) and isset($_GET['prenom']) and isset($_GET['date']) and isset($_GET['tache'])){
$fournisseur1=new fournisseur($_GET['id'],$_GET['nom'],$_GET['prenom'],$_GET['date'],$_GET['tache']);

$fournisseur1C=new fournisseurC();
$fournisseur1C->ajouterFournisseur($fournisseur1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'fournisseur ajouté ', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";

		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionfournisseur.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Facture is Not Added";
            header('Location: gestionfournisseur.php');
} 

//*/

?>