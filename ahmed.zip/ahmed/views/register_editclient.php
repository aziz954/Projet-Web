
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT Client Profile</h6>
    </div>
    <div class="card-body">
    <?php   
$connection = mysqli_connect("localhost","root","","medline");
if (isset($_POST['edit_btn3']))
{

    $id = $_POST['edit_id3'];
    $query ="SELECT * FROM client where id='$id'";
    $query_run =mysqli_query($connection ,$query);
       foreach($query_run as $row)
       {
?>

<form action="code.php"method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> Name </label>
                 <input type="text" name="edit_nom" value="<?php echo $row['nom'] ?>"  class="form-control" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label>Family Name</label>
                <input type="text" name="edit_prenom" value="<?php echo $row['prenom']?>"  class="form-control" placeholder="Enter family name">
            </div>
            <div class="form-group">
                <label>Adress</label>
                <input type="text" name="edit_adresse" value="<?php echo $row['adresse'] ?>"  class="form-control" placeholder="Enter your adress">
            </div >
            <div class="form-group">
                <label>Phone Number</label>
                <input type="text" name="edit_num" value="<?php echo $row['num'] ?>"  class="form-control" placeholder="Enter your phone number">
            </div >
            <div class="form-group">
                <label>ID</label>
                <input type="text" name="edit_id" value="<?php echo $row['id'] ?>"  class="form-control" placeholder="Enter your id">
            </div >
            <a href="gestionclient.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn3"class ="btn btn-primary ">Update</button>

</form>
            <?php


       }
   }
?>
       
               </div>
       
     



    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>