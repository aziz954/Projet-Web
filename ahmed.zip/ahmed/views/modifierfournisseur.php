
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/Fournisseur.php";
include "../core/fournisseurC.php";
if (isset($_GET['id'])){
    $fournisseurC=new fournisseurC();
    $result=$fournisseurC->recupererFournisseur($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $nom=$row['nom'];
        $prenom=$row['prenom'];
        $date=$row['date'];
        $tache=$row['tache'];
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT fournisseur </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> id </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter id">
            </div>
            <div class="form-group">
                <label>nom</label>
                <input type="text" name="nom" value="<?php echo $row['nom']; ?>" class="form-control" placeholder="Enter nom">
            </div>
            <div class="form-group">
                <label>prenom</label>
                <input type="text" name="prenom"  value="<?php echo $row['prenom']; ?>"class="form-control" placeholder="Enter prenom">
            </div >
            <div class="form-group">
                <label> date </label>
                 <input type="date" name="date"   value="<?php echo $row['date']; ?>"class="form-control" placeholder="Enter date">
            </div>
            <div class="form-group">
                <label> tache </label>
                <select name="tache"  class="form-control" value="<?php echo $row['tache']; ?>" placeholder="Enter tache"> 

                  <option value="medicaments ">medicaments</option>
                  <option value="fournitures ">fournitures </option>
                                            </select>
            </div>
            <a href="gestionfournisseur.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $fournisseur=new fournisseur($_POST['id'],$_POST['nom'],$_POST['prenom'],$_POST['date'],$_POST['tache']);
    $fournisseurC->modifierFournisseur($fournisseur,$_POST['edit_id']);
    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'fournsseur modifié', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }


    echo '<meta http-equiv="refresh" content="0; URL=gestionfournisseur.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
