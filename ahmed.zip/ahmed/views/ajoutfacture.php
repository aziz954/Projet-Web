<?PHP
include "../entities/facture.php";
include "../core/factureC.php";

if (isset($_GET['id']) and isset($_GET['mont']) and isset($_GET['id_com']) and isset($_GET['id_cl']) and isset($_GET['datef'])){
$facture1=new facture($_GET['id'],$_GET['mont'],$_GET['id_com'],$_GET['id_cl'],$_GET['datef']);

$facture1C=new factureC();
$facture1C->ajouter($facture1);
header('Location: gestionfacture.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Facture is Not Added";
            header('Location: gestionfacture.php');
}
//*/

?>