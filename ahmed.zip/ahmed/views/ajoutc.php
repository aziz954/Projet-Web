<?PHP
include "../entities/commande.php";
include "../core/commandeC.php";

if (isset($_GET['id']) and isset($_GET['id_cl']) and isset($_GET['q']) ){
$commande1=new commande($_GET['id'],$_GET['id_cl'],$_GET['q']);

$commande1C=new commandeC();
$commande1C->ajoutercommande($commande1);
header('Location: gestioncom.php');
	
}else{
	echo "vérifier les champs";
}
//*/

?>