
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/facture.php";
include "../core/factureC.php";
if (isset($_GET['id'])){
    $factureC=new factureC();
    $result=$factureC->recupererfacture($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $mont=$row['mont'];
        $id_com=$row['id_com'];
        $id_cl=$row['id_cl'];
        $datef=$row['datef'];
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT DEfactureERIES </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> id </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter id">
            </div>
            <div class="form-group">
                <label>monterence</label>
                <input type="text" name="mont" value="<?php echo $row['mont']; ?>" class="form-control" placeholder="Enter monterence">
            </div>
            <div class="form-group">
                <label>id_comesse</label>
                <input type="text" name="id_com"  value="<?php echo $row['id_com']; ?>"class="form-control" placeholder="Enter id_comesse">
            </div >
            <div class="form-group">
                <label> Time </label>
                 <input type="text" name="id_cl"   value="<?php echo $row['id_cl']; ?>"class="form-control" placeholder="Enter Time">
            </div>
            <div class="form-group">
                <label> Date </label>
                 <input type="date" name="datef"  value="<?php echo $row['datef']; ?>"class="form-control" placeholder="Enter Date">
            </div>
            <a href="gestionfacture.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $facture=new facture($_POST['id'],$_POST['mont'],$_POST['id_com'],$_POST['id_cl'],$_POST['datef']);
    $factureC->modifierfacture($facture,$_POST['edit_id']);


    echo '<meta http-equiv="refresh" content="0; URL=gestionfacture.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
