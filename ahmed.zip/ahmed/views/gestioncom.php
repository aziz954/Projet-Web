<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/commandeC.php";
$c1C=new commandeC();
$listec=$c1C->affichercommandes();
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Decery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="ajoutc.php" method="GET">

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
                <label>ID DU CLIENT</label>
                <input type="text" name="id_cl" class="form-control" placeholder="Enter Reference">
            </div>
            <div class="form-group">
                <label>QuantitE </label>
                <input type="text" name="q" class="form-control" placeholder="Enter Adresse">
            </div>

        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Decry Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add Decery Profile 
            </button>
    </h6>
  </div>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> ID DU CLIENT </th>
            <th>QUANTITE </th>
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
     <?php
foreach($listec as $row){

 
  
    ?>
    <tr>
      <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['id_cl']; ?> </td>
      <td><?php echo $row['q']; ?> </td>

      <td>
       
          <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="modifierc.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerc.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }

     ?>
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>