<?php
/**
 * 
 */
 

class prod
{
	
	private $id;
	private $pname;
	private $image;
	private $price;
	private $IDC;
	private $Quantity;
	private $affecté;
	public function getid()
	{
		return $this->id;

	}
	public function getpname()
	{
		return $this->pname;

	}
	public function getiamge()
	{
		return $this->image;

	}
	public function getprice()
	{
		return $this->price;
	}
	public function getidc()
	{
		return $this->IDC;
	}
	public function setquantity($Quantity)
	{

		return $this->Quantity;
	}
	public function getaffecte($affecté)
	{

		return $this->affecté;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	public function setpname($pname)
	{

		$this->pname=$pname;
	}
	public function setimage($image)
	{

		$this->image=$image;
	}
	public function setprice($price)
	{

		$this->price=$price;
	}
	public function setidc($IDC)
	{

		$this->IDC=$IDC;
	}
	public function setquantity($Quantity)
	{

		$this->Quantity=$Quantity;
	}
	public function setaffecte($affecté)
	{

		$this->affecté=$affecté;
	}
	
	public function construct()
	{
		$this->id=0;
		$this->pname="";
		$this->image="";
		$this->price=0;
		$this->IDC=0;
	    $this->Quantity=0;
	    $this->affecté=0;


	}
	public function __construct($id,$pname,$image,$price,$IDC,$Quantity,$affecté)
	{

		$this->id=$id;
		$this->pname=$pname;
		$this->image=$image;
		$this->price=$price;
		$this->IDC=$IDC;
		$this->Quantity=$Quantity;
		$this->affecté=$affecté;
	}
	
}

?>


