<?php
/**
 * 
 */
 

class fourniture
{
	
	private $id;
	private $nom;
	private $quantite;
	private $fournisseur;
	public function getid(){
		return $this->id;

	}
	
	public function getnom()
	{
		return $this->nom;

	}
	public function getquantite()
	{
		return $this->quantite;
	}
	public function getfournisseur()
	{
		return $this->fournisseur;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	
	public function setnom($nom)
	{

		$this->nom=$nom;
	}
	public function setquantite($quantite)
	{

		$this->quantite=$quantite;
	}
	public function setfournisseur($fournisseur)
	{

		$this->fournisseur=$fournisseur;
	}
	public function construct()
	{
		$this->id=0;
		
		$this->nom="";
        $this->quantite=0;
        $this->fournisseur=0;


	}
	public function __construct($id,$nom,$quantite,$fournisseur)
	{

		$this->id=$id;
		
		$this->nom=$nom;
		$this->quantite=$quantite;
		$this->fournisseur=$fournisseur;
	}
	
}

?>


