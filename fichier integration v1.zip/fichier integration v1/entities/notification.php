<?php
/**
 * 
 */
 

class not
{
	
	private $id;
	private $name;
	private $type;
	private $message;
	private $status;
	private $date;
	public function getid(){
		return $this->id;

	}
	public function getname()
	{
		return $this->name;

	}
	public function gettype()
	{
		return $this->type;

	}
	public function getmessage()
	{
		return $this->message;
	}
	public function getstatus()
	{
		return $this->status;
	}
	public function getdate()
	{
		return $this->date;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	public function setname($name)
	{

		$this->name=$name;
	}
	public function settype($type)
	{

		$this->type=$type;
	}
	public function setmessage($message)
	{

		$this->message=$message;
	}
	public function setstatus($status)
	{

		$this->status=$status;
	}
	public function setdate($date)
	{

		$this->date=$date;
	}
	public function construct()
	{
		$this->id=0;
		$this->name="";
		$this->type="";
		$this->message="";
		$this->status="";


	}
	public function __construct($id,$name,$type,$message,$status,$date)
	{

		$this->id=$id;
		$this->name=$name;
		$this->type=$type;
		$this->message=$message;
		$this->status=$status;
		$this->date=$date;
	}
	
}

?>


