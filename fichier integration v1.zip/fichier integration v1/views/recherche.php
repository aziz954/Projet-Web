<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/photoCore.php";
include "../core/loginC.php";

$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>
<script language="javascript"type="text/javascript" src="veriflog.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="ajoutlog.php" method="GET" id ="myform">

        <div class="modal-body">

            <div class="form-group"enctype="multipart/form-data">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id" id="id">
            </div>
            
            <div class="form-group">
                <label>UserType</label>
                <input type="text" name="usertype" class="form-control" placeholder="Enter usertype"id="adr">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username"id="time">
            </div>
               <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email"id="date">
            </div>
                 <div class="form-group">
                <label>image</label>
                <input type="file" name="image" class="form-control" placeholder="Enter email"id="date">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="email" class="form-control" placeholder="Enter password"id="date">
            </div>
                <div class="form-group">
                <label> Confirm Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password"id="date">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary"onsubmit = "return validate();">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
  <form method="POST">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search" d="search"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Delivry Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">              <i class="fas fa-plus-square"></i>

              Add Delivery Profile 
            </button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">Print</button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

  
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>
  <div id="result"></div>
    
          
        
     

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->
<script>
$(document).ready(function(){
  load_data();
  function load_data(query)
  {
    $.ajax({
      url:"fetchlog.php",
      method:"post",
      data:{query:query},
      success:function(data)
      {
        $('#result').html(data);
      }
    });
  }
  
  $('#search').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
      load_data(search);
    }
    else
    {
      load_data();      
    }
  });
});
</script>
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>