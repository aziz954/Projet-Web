<?PHP
include "../entities/vendeur.php";
include "../core/vendeurC.php";

if (!empty($_GET['id']) and !empty($_GET['nom']) and !empty($_GET['prenom']) and !empty($_GET['num']) ){
$ven1=new ven($_GET['id'],$_GET['nom'],$_GET['prenom'],$_GET['num']);

$ven1C=new venC();
$ven1C->ajouter($ven1);
	  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A seller has been added', 'unread', CURRENT_TIMESTAMP, 'gestionvend.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionvend.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Vendeurs is Not Added";
            header('Location: gestionvend.php');
}
//*/

?>