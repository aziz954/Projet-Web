

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->
      </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->

    <script src="js/sweetalert.js"></script>

<script src="https://code.jquery.com/jquery-3.5.0.min.js" ></script>
    <script >

      $(document).ready(function(){
      $('.delete_btn_ajax').click(function(e){
e.preventDefault();
var deleteid=$(this).closest("tr").find('.delete_id_value').val();
//console.log(deleteid);
swal({
  title: "Are you sure?",
  text: "Once deleted, you will not be able to recover this data!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
 $.ajax({



  type:"POST",
  url:"code.php",
  data:{
   "delete_btn_set":1,
   "delete_id":deleteid, 
  },
  success:function(response)
  {
swal("Data deleted Successfully.!",{
icon:"success",
}).then ((result)=>{
      document.location = document.location.href ;

});
  }
 });


  } 
});

      });
    });
    </script>
</body>

</html>
