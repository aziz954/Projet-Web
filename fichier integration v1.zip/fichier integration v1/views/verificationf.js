function verifier() {
    var errors ="";
    if(document.myform.nom.value==""){
    errors += "b";
    }
    if(document.myform.quantite.value==""){
        errors += "a";
        }
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    }