function verifier() {
    var errors ="";
   
    
    if(document.myform.id.value==""){
    
        errors += "a";
        alert('saisir un ID');
    
    }

    if(document.myform.nom.value==""){
    
        errors += "b";
        alert('saisie un nom');
    

        
    }

    if(document.myform.prenom.value==""){
    
        errors += "b";
        alert('saisie une quantite');
    
    }
    
    if(document.myform.num.value==""){
    
        errors += "b";
        alert('saisie une quantite');
    
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        errors += "c";
        alert("Id doit etre de longueur egale a 8");
    
    }

    if(document.myform.num.value.length < 8 || document.myform.num.value.length > 8 ){
        errors += "c";
        alert("num doit etre de longueur egale a 8");
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }

