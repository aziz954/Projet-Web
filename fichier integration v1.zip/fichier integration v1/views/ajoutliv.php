<?PHP
include "../entities/livraison.php";
include "../core/livraisonC.php";

if (!empty($_GET['id']) and !empty($_GET['ref']) and !empty($_GET['adr']) and !empty($_GET['heure']) and !empty($_GET['datee'])){
$liv1=new liv($_GET['id'],$_GET['ref'],$_GET['adr'],$_GET['heure'],$_GET['datee']);

$liv1C=new livC();
$liv1C->ajouter($liv1);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionliv.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Delivery is Not Added";
            header('Location: gestionliv.php');
}
//*/

?>