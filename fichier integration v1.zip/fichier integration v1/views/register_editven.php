
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/vendeur.php";
include "../core/vendeurC.php";
if (isset($_GET['id'])){
    $venC=new venC();
    $result=$venC->recupererven($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $nom=$row['nom'];
        $prenom=$row['prenom'];
        $num=$row['num'];
        
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT VENDEURS </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
            <div class="form-group">
                <label>Nom</label>
                <input type="text" name="nom" value="<?php echo $row['nom']; ?>" class="form-control" placeholder="Enter Reference">
            </div>
            <div class="form-group">
                <label>Prenom</label>
                <input type="text" name="prenom"  value="<?php echo $row['prenom']; ?>"class="form-control" placeholder="Enter Adresse">
            </div >
            <div class="form-group">
                <label> Num </label>
                 <input type="text" name="num"   value="<?php echo $row['num']; ?>"class="form-control" placeholder="Enter Time">
            </div>
           
            <a href="gestionven.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $ven=new ven($_POST['id'],$_POST['nom'],$_POST['prenom'],$_POST['num']);
    $venC->modifierven($ven,$_POST['edit_id']);

     $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'A seller has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionvend.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    echo '<meta http-equiv="refresh" content="0; URL=gestionvend.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
