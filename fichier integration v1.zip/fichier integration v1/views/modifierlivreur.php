
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/livreur.php";
include "../core/livreurC.php";
if (isset($_GET['id'])){
    $livrC=new livrC();
    $result=$livrC->recupererlivr($_GET['id']);
    foreach($result as $row){
        $nom=$row['nom'];
        $prenom=$row['prenom'];
        $id=$row['id'];
        $idliv=$row['idliv'];
       $mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM livruer");
        ?>
        <script language="javascript"type="text/javascript" src="verifmoflivr.js"></script>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT DELIVERIES </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> nom </label>
                 <input type="text" name="nom" value="<?php echo $row['nom']; ?>" class="form-control" placeholder="Enter nom" >
            </div>
         
            <div class="form-group">
                <label>prenom</label>
                <input type="text" name="prenom"  value="<?php echo $row['prenom']; ?>"class="form-control" placeholder="Enter prenom">
            </div >
            <div class="form-group">
                <label> id </label>
                 <input type="text" name="id"   value="<?php echo $row['id']; ?>"class="form-control" placeholder="Enter id"readonly>
            </div>
            <div class="form-group">
                <label> idliv </label>
                 <input type="text" name="idliv"  value="<?php echo $row['idliv']; ?>"class="form-control" placeholder="Enter id lvreuer">
            </div>
            <a href="gestionlivreur.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
      if (isset($_POST['updatebtn2']) and !empty($_POST['nom']) and !empty($_POST['prenom']))
      {
    
    $livr=new livr($_POST['nom'],$_POST['prenom'],$_POST['id'],$_POST['idliv']);
    $livrC->modifierlivr($livr,$_POST['edit_id']);

      $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Deleviry has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionlivreur.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    echo '<meta http-equiv="refresh" content="0; URL=gestionlivreur.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
