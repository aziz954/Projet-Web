<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "SELECT * FROM register WHERE CONCAT(`id`, `usertype`, `username`, `email`, `password`, `image`) LIKE '%".$search."%'";
}
else
{
	$query = "
	SELECT * FROM register ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th>ID</th>  
           <th>Usertype</th>  
           <th>Username</th>  
           <th>Email</th> 
          <th>Password</th> 
          <th>Image</th>  
 
 
          <td align="center" colspan="2">Actions</td> 
      </tr>  
 ';  

	while($row = mysqli_fetch_array($result))
	{
	 $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["usertype"] . '</td>  
           <td>' . $row["username"] . '</td>  
           <td>' . $row["email"] . '</td>  
            <td>' . $row["password"] . '</td> 
              <td>' . $row["image"] . '</td>  
 

             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="register_edit.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
  <i class="fas fa-edit"></i></a>
      </td>
  <td>

        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>