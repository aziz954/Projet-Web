<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/photoCore.php";
include "../core/loginC.php";

$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>
<script language="javascript"type="text/javascript" src="veriflog.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  

<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="ajoutlog.php" method="GET" id ="myform" name="myform">

        <div class="modal-body">

            <div class="form-group"enctype="multipart/form-data">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id" id="id">
            </div>
            
            <div class="form-group">
                <label>UserType</label>
                <input type="text" name="usertype" class="form-control" placeholder="Enter usertype"id="adr">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username"id="time">
            </div>
               <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email"id="date">
            </div>
                 <div class="form-group">
                <label>image</label>
                <input type="file" name="image" class="form-control" placeholder="Enter email"id="date">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="email" class="form-control" placeholder="Enter password"id="date">
            </div>
                <div class="form-group">
                <label> Confirm Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password"id="date">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary"onsubmit = "return validate();">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
  <form method="POST">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Delivry Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">              <i class="fas fa-plus-square"></i>

            </button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()"><i class="fas fa-print"></i>   </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

  
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive" id="employee_table">

      <table class="table table-bordered" name ="tab" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th><a class="column_sort" id="nom" data-order="desc" href="#"> ID </a> </th>
            <th> <a class="column_sort" id="usertype" data-order="desc" href="#">Usertype </a></a> </a> </th>
            <th> <a class="column_sort" id="username" data-order="desc" href="#">Username </a> </a> </th>
            <th> <a class="column_sort" id="email" data-order="desc" href="#">Email </a> </th>
            <th> <a class="column_sort" id="password" data-order="desc" href="#">Password </a> </th>
            <th> <a class="column_sort" id="image" data-order="desc" href="#">Image </a> </th>
            <td align="center" colspan="2">Actions</td>
          </tr>
        </thead>
        <tbody>

    

    <?php
if(isset($_POST['submit']))
{
$URL="recherche.php";
echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}

?>

     <?php
       $page1=0;
     if (!empty($_GET['page'])){
     $page=$_GET["page"];
if($page=="" || $page=="1")
{
  $page1=0;
}
else
{
  $page1=($page*5)-5;
}
}
$res= mysqli_query($mysqli,"SELECT * FROM register order by id DESC limit $page1,5 ");
while($row=mysqli_fetch_array($res)):

 
  
    ?>
    <tr>
      <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
      <td><?php echo $row['image']; ?> </td>


      <td align="center">
       
          <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="register_edit.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  <i class="fas fa-edit"></i></a>
      </td>
      <td align="center">
  <input type="hidden" class="delete_id_value"value="<?php echo $row['id']; ?>">
         <a href="javascript:void(0)" class="delete_btn_ajax btn btn-danger"> <i class="fas fa-trash-alt"></i></a>

      </td>
    </tr>
    
<?php endwhile ; ?>
<?php
  $res1=mysqli_query($mysqli,"SELECT * FROM register  ");
  $cou=mysqli_num_rows($res1);
  $a=$cou/5;
  $a=ceil($a);
  echo"<br>"; echo"<br>";
  for($b=1;$b<=$a;$b++)
  {
    ?><a href="register.php?page=<?php echo $b ?>"class='btn btn-primary'style="text -decoration:none"><?php echo $b." "; ?></a><?php
  }
 


     ?>
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->
<style>

h5 {
    text-align: center;
}
 </style>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
 
  <h5>
    <a href="fpdf/livpdf.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate pdf</a>
      </h5>

<h5>
   <a href="exel/index.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate exel</a>
    </h5>
</div>
<script>  
 $(document).ready(function(){  
      $(document).on('click', '.column_sort', function(){  
           var column_name = $(this).attr("id");  
           var order = $(this).data("order");  
           var arrow = '';  
           //glyphicon glyphicon-arrow-up  
           //glyphicon glyphicon-arrow-down  
           if(order == 'desc')  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';  
           }  
           else  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';  
           }  
           $.ajax({  
                url:"sortlog.php",  
                method:"POST",  
                data:{column_name:column_name, order:order},  
                success:function(data)  
                {  
                     $('#employee_table').html(data);  
                     $('#'+column_name+'').append(arrow);  
                }  
           })  
      });  
 });  
 </script> 
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>