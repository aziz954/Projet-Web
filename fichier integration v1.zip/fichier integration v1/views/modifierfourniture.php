
<?php
include('security.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../entities/fourniture.php";
include "../core/fournitureC.php";
if (isset($_GET['id'])){
    $fournitureC=new fournitureC();
    $result=$fournitureC->recupererfourniture($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $nom=$row['nom'];
        $quantite=$row['quantite'];
        $fournisseur=$row['fournisseur'];
        $mysqli=NEW MySQLi('localhost','root','','medline');
        $result=$mysqli->query("SELECT fournisseur FROM fournisseur");
        ?>
        <script language="javascript"type="text/javascript" src="verificationf.js"></script>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT Product </h6>
    </div>
    <div class="card-body">

<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="number" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
           
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="nom"  value="<?php echo $row['nom']; ?>"class="form-control" placeholder="Enter Name">
            </div >
            <div class="form-group">
                <label>Quantity</label>
                 <input type="number" name="quantite"   value="<?php echo $row['quantite']; ?>"class="form-control" placeholder="Enter Quantity">
            </div>
            
            <div class="form-group">
                <label>fournisseur</label>
                <select name="fournisseur"id="fournisseur">
                        <?php
                          while($rows = $result->fetch_assoc())
                          {
                              $fournisseur=$rows['fournisseur'];
                                  echo"<option value='$fournisseur'>$fournisseur</option>";
                          }
                        ?>
                </select>
            </div>
            <a href="gestionfourniture.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])and !empty($_POST['nom'])and !empty($_POST['quantite'])){
    
    $fourniture=new fourniture($_POST['id'],$_POST['nom'],$_POST['quantite'],$_POST['fournisseur']);
    $fournitureC->modifierfourniture($fourniture,$_POST['edit_id']);
    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Product has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionlivreur.php');";
    $db = config::getConnexion();

    try{
  
                    $req=$db->prepare($sql);

        $req->execute();
       
    }
      catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }

    echo '<meta http-equiv="refresh" content="0; URL=gestionfourniture.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
