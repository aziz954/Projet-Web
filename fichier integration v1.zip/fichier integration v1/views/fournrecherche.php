<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/fournitureC.php";
$fourniture1C=new fournitureC();
$listefourniture=$fourniture1C->afficherfourniture();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT fournisseur as fournisseur FROM fournisseur");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>



<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form name="myform" action="ajoutfourniture.php" method="GET" id ="myform" >

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                  <input type="text" minlength="8" maxlength="8" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
            <label> Name </label>
                  <input type="text"  name="nom" class="form-control" placeholder="Enter Name">
            </div>
            <div class="form-group">
            <label> Quantity </label>
                  <input type="text"  name="quantite" class="form-control" placeholder="Enter Quantity">
            </div>
            <div class="form-group">
                <label>fournisseur</label>
                <select name="fournisseur"id="fournisseur">
                
<?php
while($rows = $result->fetch_assoc())
{
$fournisseur=$rows['fournisseur'];
echo"<option value='$fournisseur'>$fournisseur</option>";
}
?>
                </select>
            </div>
            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
  <form method="POST"action="">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small"  name="search_text" id="search_text"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Fourniture Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
<i class="fas fa-plus-square"></i>            
</button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()"><i class="fas fa-print"></i></button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

 
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

      <div id="result"></div>

  </div>
</div>

</div>
<!-- /.container-fluid -->
<script>
$(document).ready(function(){
  load_data();
  function load_data(query)
  {
    $.ajax({
      url:"fetchf.php",
      method:"post",
      data:{query:query},
      success:function(data)
      {
        $('#result').html(data);
      }
    });
  }
  
  $('#search_text').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
      load_data(search);
    }
    else
    {
      load_data();      
    }
  });
});
</script>



<?php
include('includes/scripts.php');
include('includes/footer.php');
?>