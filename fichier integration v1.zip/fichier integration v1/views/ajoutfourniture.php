<?PHP
include "../entities/fourniture.php";
include "../core/fournitureC.php";

if (!empty($_GET['id'])  and !empty($_GET['nom']) and !empty($_GET['quantite']) and !empty($_GET['fournisseur'])){
$fourniture1=new fourniture($_GET['id'],$_GET['nom'],$_GET['quantite'],$_GET['fournisseur']);

$fourniture1C=new fournitureC();
$fourniture1C->ajouter($fourniture1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A Product has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }




header('Location: gestionfourniture.php');
	
header('Location:gestionfourniture.php?message=<div class="alert alert-success">success</div>');	
}
else{
  if (empty($_GET['id'])){
    header('Location:gestionfourniture.php?message=<div class="alert alert-danger">id missing</div>');
  } 
  if (empty($_GET['nom'])){
    header('Location:gestionfourniture.php?message=<div class="alert alert-danger">name missing</div>');
  } 
  if (empty($_GET['quantite'])){
    header('Location:gestionfourniture.php?message=<div class="alert alert-danger">quantity missing</div>');
  }
}
//*/

?>