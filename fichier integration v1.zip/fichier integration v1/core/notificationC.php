<?PHP
include "../config.php";
class notC {
function afficher ($not){
		echo "id: ".$not->getid()."<br>";
		echo "name: ".$not->getname()."<br>";
		echo "type: ".$not->gettype()."<br>";
		echo "message: ".$not->getmessage()."<br>";
		echo "status".$not->getstatus()."<br>";
	echo "date".$not->getdate()."<br>";
	}
	
	function ajouter($not){
		$sql="insert into notifications (id,name,type,message,status,date)
 values (:id, :name,:type,:message,:status,date)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$not->getid();
        $name=$not->getname();
        $type=$not->gettype();
        $message=$not->getmessage();
        $status=$not->getstatus();
		$req->bindValue(':id',$id);
		$req->bindValue(':name',$name);
		$req->bindValue(':type',$type);
		$req->bindValue(':message',$message);
		$req->bindValue(':status',$status);
		$req->bindValue(':date',$date);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
		function ajouter2(){
		$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date`) VALUES (NULL, 'User', 'Ajout', 'A user/admin has been added', 'unread', '2020-04-23 12:30:31');";
		$db = config::getConnexion();
		try{
      
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	function affichernot(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From notifications";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimernot($id){
		$sql="DELETE FROM notifications where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifiernot($not,$id){
		$sql="UPDATE notifications SET id=:id, name=:name,type=:type,message=:message,status=:status,date=:date WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$not->getid();
        $name=$not->getname();
        $type=$not->gettype();
        $message=$not->getmessage();
        $status=$not->getstatus();
        $date=$not->getdate();
		$datas = array(':id'=>$id, ':name'=>$name, ':type'=>$type,':message'=>$message,':status'=>$status,'date'=>$date);
		$req->bindValue(':id',$id);
		$req->bindValue(':name',$name);
		$req->bindValue(':type',$type);
		$req->bindValue(':message',$message);
		$req->bindValue(':status',$status);
		$req->bindValue(':date',$date);
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recuperernot($id){
		$sql="SELECT * from notifications where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeEmployes($tarif){
		$sql="SELECT * from livraison where tarifHoraire=$tarif";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
