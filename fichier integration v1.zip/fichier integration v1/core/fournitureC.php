<?PHP
include "../config.php";
class fournitureC {
function afficher ($fourniture){
		echo "id: ".$fourniture->getid()."<br>";
		echo "nom: ".$fourniture->getnom()."<br>";
		echo "quantite: ".$fourniture->getquantite()."<br>";
		echo "fournisseur".$fourniture->getfournisseur()."<br>";
	}
	
	function ajouter($fourniture){
		$sql="insert into fourniture (id,nom,quantite,fournisseur)
 values (:id,:nom,:quantite,:fournisseur)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$fourniture->getid();
        $nom=$fourniture->getnom();
        $quantite=$fourniture->getquantite();
        $fournisseur=$fourniture->getfournisseur();
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':fournisseur',$fournisseur);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherfourniture(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From fourniture";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerfourniture($id){
		$sql="DELETE FROM fourniture where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierfourniture($fourniture,$id){
		$sql="UPDATE fourniture SET id=:id,nom=:nom,quantite=:quantite,fournisseur=:fournisseur WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$fourniture->getid();
       
        $nom=$fourniture->getnom();
        $quantite=$fourniture->getquantite();
        $fournisseur=$fourniture->getfournisseur();
		$datas = array(':id'=>$id, ':nom'=>$nom,':quantite'=>$quantite,':fournisseur'=>$fournisseur);
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':fournisseur',$fournisseur);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererfourniture($id){
		$sql="SELECT * from fourniture where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	

}

?>
