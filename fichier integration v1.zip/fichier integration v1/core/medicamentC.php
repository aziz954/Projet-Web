<?PHP
include "../config.php";
class medicamentC {
function afficher ($medicament){
		echo "id: ".$medicament->getid()."<br>";
		echo "nom: ".$medicament->getnom()."<br>";
		echo "quantite: ".$medicament->getquantite()."<br>";
		echo "fournisseur".$medicament->getfournisseur()."<br>";
	}
	
	function ajouter($medicament){
		$sql="insert into medicament (id,nom,quantite,fournisseur)
 values (:id,:nom,:quantite,:fournisseur)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$medicament->getid();
        $nom=$medicament->getnom();
        $quantite=$medicament->getquantite();
        $fournisseur=$medicament->getfournisseur();
		$req->bindValue(':id',$id);

		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':fournisseur',$fournisseur);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function affichermedicament(){
	//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From medicament";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimermedicament($id){
		$sql="DELETE FROM medicament where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifiermedicament($medicament,$id){
		$sql="UPDATE medicament SET id=:id,nom=:nom,quantite=:quantite,fournisseur=:fournisseur WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$medicament->getid();
       
        $nom=$medicament->getnom();
        $quantite=$medicament->getquantite();
        $fournisseur=$medicament->getfournisseur();
		$datas = array(':id'=>$id, ':nom'=>$nom,':quantite'=>$quantite,':fournisseur'=>$fournisseur);
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
		$req->bindValue(':fournisseur',$fournisseur);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recuperermedicament($id){
		$sql="SELECT * from medicament where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
}

?>
