<?PHP
include "C:/xampp/htdocs/admin/config.php";
class productC {
function afficher ($product){
		echo "id: ".$product->getid()."<br>";
		echo "nom: ".$product->getnom()."<br>";
		echo "quantite: ".$product->getquantite()."<br>";
        echo "image".$product->getimage()."<br>";
		echo "prix".$product->getprix()."<br>";
		echo "description".$product->getdescription()."<br>";

	}
	
	function ajouter($product){
		$sql="insert into producto (id,nom,quantite,image,prix,description)
 values (:id,:nom,:quantite,:image,:prix,:description)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$product->getid();
        $nom=$product->getnom();
        $quantite=$product->getquantite();
        $image=$product->getimage();
		$prix=$product->getprix();
		$description=$product->getdescription();


		$req->bindValue(':id',$id);

		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
        $req->bindValue(':image',$image);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':description',$description);

		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherproduct(){
	//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From producto";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerproduct($id){
		$sql="DELETE FROM producto where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierproduct($product,$id){
		$sql="UPDATE producto SET id=:id,nom=:nom,quantite=:quantite,image=:image,prix=:prix,description=:description WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$product->getid();
       
        $nom=$product->getnom();
        $quantite=$product->getquantite();
        $image=$product->getimage();
		$prix=$product->getprix();
		$description=$product->getdescription();


        $datas = array(':id'=>$id, ':nom'=>$nom,':quantite'=>$quantite,':image'=>$image, ':prix'=>$prix, ':description'=>$description);
        



        $req->bindValue(':id',$id);
        
		$req->bindValue(':nom',$nom);
		$req->bindValue(':quantite',$quantite);
        $req->bindValue(':image',$image);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':description',$description);


		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererproduct($id){
		$sql="SELECT * from producto where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	
	
}

?>
