<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/photoCore.php";
include "../core/loginC.php";
$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<script language="javascript"type="text/javascript" src="livcontrole.js"></script>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="ajoutlog.php" method="GET" id ="myform">

        <div class="modal-body">

            <div class="form-group"enctype="multipart/form-data">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id" id="id">
            </div>
            
            <div class="form-group">
                <label>UserType</label>
                <input type="text" name="usertype" class="form-control" placeholder="Enter usertype"id="adr">
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter username"id="time">
            </div>
               <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email"id="date">
            </div>
                 <div class="form-group">
                <label>image</label>
                <input type="file" name="image" class="form-control" placeholder="Enter email"id="date">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="email" class="form-control" placeholder="Enter password"id="date">
            </div>
                <div class="form-group">
                <label> Confirm Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password"id="date">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary"onsubmit = "return validate();">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
  <form method="POST">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Delivry Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add Delivery Profile 
            </button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">Print</button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

  <button type="submit"name="tric"id="close-image"><img src="img/lcroi.png"></button>
<button type="submit" name="trid"id="close-image"><img src="img/ldesc.png"></button>
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> Usertype </th>
            <th>Username </th>
            <th>Email</th>
            <th>Password</th>
            <th>Image</th>
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
<?php

 if ((isset($_POST['trid']))){
 $listeliv=$liv1C->tridesc();
 foreach($listeliv as $row){

?>
<tr>
  <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
      <td>
       
    <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="register_edit.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>

<?php

  if  (isset($_POST['tric'])){
 $listeliv=$liv1C->tri();
 foreach($listeliv as $row){

?>
<tr>
  <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
      <td>
       
    <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="register_edit.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>



           <?php

  if (isset($_POST['submit'])){
   $listelog=$log1C->rechercherListelog($_POST['search']);
 foreach($listeliv as $row){

?>
<tr>
  <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
      <td>
       
    <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="register_edit.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>

     <?php
       $page1=0;
     if (isset($_GET['page'])){
     $page=$_GET["page"];
if($page=="" || $page=="1")
{
  $page1=0;
}
else
{
  $page1=($page*5)-5;
}
}
$res=mysqli_query($mysqli,"SELECT * FROM register limit $page1,5 ");
while($row=mysqli_fetch_array($res))
{

                     $photoCoreInstance=new photoCore();

  
    ?>
    <tr>
      <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
                <td> <img src="<?php echo $row["image"]; ?>"  width="100" height="100" alt="item">
</td>

      <td>
       
          <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="register_edit.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
}

  $res1=mysqli_query($mysqli,"SELECT * FROM register  ");
  $cou=mysqli_num_rows($res1);
  $a=$cou/5;
  $a=ceil($a);
  echo"<br>"; echo"<br>";
  for($b=1;$b<=$a;$b++)
  {
    ?><a href="register.php?page=<?php echo $b ?>"class='btn btn-primary'style="text -decoration:none"><?php echo $b." "; ?></a><?php
  }
 


     ?>
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>