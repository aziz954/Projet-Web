function validate(){
  var id = document.getElementById("nom").value;
  var ref = document.getElementById("prenom").value;
  var adr = document.getElementById("id").value;
  var time = document.getElementById("idliv").value;
  var error_message = document.getElementById("error_message");
  
  error_message.style.padding = "10px";
  
  var text;
  =
  if(id < 5){
    text = "Please Enter Correct id";
    error_message.innerHTML = text;
    return false;
  }
  if(isNaN(id) || id.length != 8){
    text = "Please Enter valid Phone Number";
    error_message.innerHTML = text;
    return false;
  }
  if(email.indexOf("@") == -1 || email.length < 6){
    text = "Please Enter valid Email";
    error_message.innerHTML = text;
    return false;
  }

  alert("Form Submitted Successfully!");
  return true;
}