
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/client.php";
include "../core/clientC.php";
if (isset($_GET['id']))
{
    $clientC=new clientC();
    $result=$clientC->recupererclient($_GET['id']);
    foreach($result as $row)
    {
        $nom=$row['nom'];
        $prenom=$row['prenom'];
        $adresse=$row['adresse'];
        $num=$row['num'];
        $id=$row['id'];
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT Client </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

 
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="nom" value="<?php echo $row['nom']; ?>" class="form-control" placeholder="Enter name">
            </div>
            <div class="form-group">
                <label>FNAME</label>
                <input type="text" name="prenom" value="<?php echo $row['prenom']; ?>"class="form-control" placeholder="Enter fname">
            </div >
            <div class="form-group">
                <label> Adress </label>
                 <input type="text" name="adresse" value="<?php echo $row['adresse']; ?>"class="form-control" placeholder="Enter Time">
            </div>
            <div class="form-group">
                <label> Phone number </label>
                 <input type="number" name="num" value="<?php echo $row['num']; ?>"class="form-control" placeholder="Enter numtel">
            </div>
             <div class="form-group">
                <label> ID </label>
                 <input type="number" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
            <a href="gestionclient.php" class="btn btn-danger">CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary">Update</button>

</form>
       
               </div>
       <?PHP 
   }

     }  
       
       
     if (isset($_POST['updatebtn2']))
     {
    
    $client=new client($_POST['nom'],$_POST['prenom'],$_POST['adresse'],$_POST['num'],$_POST['id']);
    $clientC->modifier($client,$_POST['edit_id']);
    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'A client has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }


    echo '<meta http-equiv="refresh" content="0; URL=gestionclient.php">';
    }
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>