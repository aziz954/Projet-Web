function verifier() {
    var errors ="";
   
    
    if(document.myform.nom.value==""){
    
        errors += "a";
        alert('saisir un le nom');
    
    }

    if(document.myform.prenom.value==""){
    
        errors += "b";
        alert('saisie le prenom');
    

        
    }

    if(document.myform.id.value==""){
    
        errors += "b";
        alert('saisir l id du livreur');
    
    }

    if(document.myform.idliv.value==""){
    
        errors += "b";
        alert('saisir id de la livrairon');
    
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        errors += "c";
        alert("Id doit etre de longueur egale a 8");
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }

