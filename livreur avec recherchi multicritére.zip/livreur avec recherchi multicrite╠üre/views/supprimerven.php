<?PHP
include "../core/vendeurC.php";
$venC=new venC();
if (isset($_POST["id"])){
  $venC->supprimerven($_POST["id"]);
   $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A seller has been Deleted', 'unread', CURRENT_TIMESTAMP, 'gestionvend.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: gestionvend.php');
}

?>