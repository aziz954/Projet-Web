function verifier() {
    var errors ="";
   
    
    if(document.myform.id.value==""){
    
        errors += "a";
        alert('saisir un ID');
    
    }

    if(document.myform.adr.value==""){
    
        errors += "b";
        alert('saisie une adresse');
    

        
    }

    if(document.myform.heure.value==""){
    
        errors += "b";
        alert('saisir une heure');
    
    }

    if(document.myform.datee.value==""){
    
        errors += "b";
        alert('saisir une date');
    
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        errors += "c";
        alert("Id doit etre de longueur egale a 8");
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }

