<?PHP
include "../entities/Avis.php";
include "../core/avisC.php";

if (isset($_GET['id_client']) and isset($_GET['type']) and isset($_GET['avis'])){
$avis1=new Avis(    $_GET['id_cleint'],$_GET['type'],$_GET['avis']);

$avis1C=new avisC();
$avis1C->ajouter($avis1);
header('Location: welcome.html');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Facture is Not Added";
            header('Location: contact.php');
}
//*/

?>