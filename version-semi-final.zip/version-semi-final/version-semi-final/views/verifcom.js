function verifier() {
    var errors ="";
    if(document.myform.q.value==""){
    errors += "b";
    }
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    }

