
<?php
//include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/livraison.php";
include "../core/livraisonC.php";
if (isset($_GET['id'])){
    $livC=new livC();
    $result=$livC->recupererliv($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $ref=$row['ref'];
        $adr=$row['adr'];
        $heure=$row['heure'];
        $datee=$row['datee'];
       $mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id as ref FROM vendeurs");
        ?>

<!--End topbar header-->
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Editing Delevries Form</h4>
		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editing Delevries </li>
         </ol>
	   </div>
	   <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->


  

		  <div class="row">
			<div class="col-lg-12">
			   
			 
       <div class="card">
        <form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
           <div class="card-body">
           <div class="card-title">Editing Delevries </div>
           <hr>
            <form>
           <div class="form-group row">
            <label for="input-26" class="col-sm-2 col-form-label">ID :</label>
            <div class="col-sm-10">
            <input type="text" class="form-control form-control-rounded" id="id"name="id" value="<?php echo $row['id']; ?>" placeholder="Enter Your id"readonly>
            </div>
          </div>
          <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">reference :</label>
                  <div class="col-sm-10">     
                     
                    <select class="form-control" id="input-6" name="ref" required>
                              <?php
while($rows = $result->fetch_assoc())
{$ref=$rows['ref'];
echo"<option value='$ref'>$ref</option>";
}
?>
                    </select>
                  </div>
                </div>

          <div class="form-group row">
            <label for="input-27" class="col-sm-2 col-form-label">Adresse :</label>
            <div class="col-sm-10">
            <input type="text" class="form-control form-control-rounded" id="adr" name="adr" value="<?php echo $row['adr']; ?>"placeholder="Enter Your  Address">
            </div>
          </div>
          <div class="form-group row">
            <label for="input-28" class="col-sm-2 col-form-label">Time :</label>
            <div class="col-sm-10">
            <input type="time" class="form-control form-control-rounded" name="heure" value="<?php echo $row['heure']; ?>"id="input-28" placeholder="Enter Your Time">
            </div>
          </div>
          <div class="form-group row">
            <label for="input-29" class="col-sm-2 col-form-label">Date:</label>
            <div class="col-sm-10">
            <input type="date" class="form-control form-control-rounded"name="datee" value="<?php echo $row['datee']; ?>" id="datee" placeholder="Enter Date">
            </div>
          </div>
         
       
         
                <div class="form-footer">
                    <a href="afficherliv.php" class="btn btn-danger fa fa-mail-reply"></a>
                    <button  type="submit" class="btn btn-success fa fa-edit" name="updatebtn2" onclick="anim5_noti()"></button>
                   
                </div>
          </form>
         </div>
         </div>

			</div>
            <?PHP

   }

     }  
          
     if (isset($_POST['updatebtn2'])and !empty($_POST['adr'])and !empty($_POST['heure'])and !empty($_POST['datee'])){
    
    $liv=new liv($_POST['id'],$_POST['ref'],$_POST['adr'],$_POST['heure'],$_POST['datee']);
    $livC->modifierliv($liv,$_POST['edit_id']);

      $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Deleviry has been Modified', 'unread', CURRENT_TIMESTAMP, 'afficherliv.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    echo '<meta http-equiv="refresh" content="0; URL=afficherliv.php">';
}
?>
		  </div><!--End Row-->
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2019 Bulona Admin
        </div>
      </div>
    </footer>
	<!--End footer-->
	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
	
	
	 <p class="mb-0">Header Colors</p>
      <hr>
	  
	  <div class="mb-3">
	    <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
	  </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
	  
      <div class="mb-3">
	    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
	  </div>
	  
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->

<?php
include('includes/scripts.php'); 
include('includes/footer.php'); 


        ?>