
<?php
include('includes/header.php');
include('includes/navbar.php');
include "../core/avisC.php";

if (isset($_GET['id_client'])){
  $avisr=new avisC();
    $result=$avisr->recupererAvis($_GET['id_client']);
  foreach($result as $row){
    $id_client=$row['id_client'];
    $type=$row['type'];
    $avis=$row['avis'];
?>
<nav class="breadcrumb" aria-label="breadcrumbs">

  

  
  <h1>Avis</h1>
  <a href="../index.html" title="Back to the frontpage">Home</a>

  <span aria-hidden="true" class="breadcrumb__sep">&#47;</span>
  <span>Avis</span>

  
</nav>
<div class="dt-sc-hr-invisible-large"></div> 




  
  <main class=" main-content  ">  

  


    
      
      
      <div class="grid-uniform">
        <div class="grid__item">  
          <div class="container-bg"> 
            <div class="grid">
  <div class="grid__item">
    <div id="shopify-section-contact-us" class="shopify-section">



        
<div class="contact-address">
  <div class="container">
    <div class="dt-sc-hr-invisible-large"></div>
    
    <div class="dt-sc-hr-invisible-medium"></div>
    <div class="grid__item">
      <div class="contact-form-section">
  <form action="modifieravis.php" method="POST">
    
                                      <div class="p-3 p-lg-5 border">
               
                                     <div class="form-group row">
                 
                                     <div class="col-md-6">
                   
                                     <label for="c_fname" class="text-black"> ID <span class="text-danger">*</span></label>
                                     <input type="text" class="form-control" id="id_client" name="id_client" required="required" value="<?PHP echo $id_client ?>">
                                     </div>
                  
                                      </div>
                                      <div class="form-group row">
                 
                                      </div>
                                                 <div class="form-group row">
                                                 <div class="col-md-12">
                                                 <label for="avis">Type:</label>

                                            <select name="type" required="required" class="controle" value="<?PHP echo $type ?>"> 

                  <option value="livraison ">livraison</option>
                  <option value="produit ">produits </option>
                                            </select>
                                                  </div>
                                                  </div>
    
                                      <div class="form-group row">
                                      <div class="col-md-12">
               <label for="c_message" class="text-black" >AVIS </label>
   <input name="avis"  cols="30" rows="7" class="form-control" required="required"  id="avis" value="<?PHP echo $avis ?>">
                                       </div>
                                      </div>
                                                <div class="form-group row">
                                                <div class="col-lg-12">
 <input type="submit" name="modifier"  class="btn btn-primary btn-lg btn-block"  >
                                                </div>
           <input type="hidden" name="id_client_ini" value="<?PHP echo $_GET['id_client'];?>">
                                                 </div>
                                                </div>
               </form>
<?PHP
  }
}
if (isset($_POST['modifier'])){
  $avis=new avis($_POST['id_client'],$_POST['type'],$_POST['avis']);
  $avisC=new avisC();
  $avisC->modifierAvis($avis,$_POST['id_client_ini']);
  echo "<script>alert('la modification est effectutée avec succes')</script>";
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'Avis modifé', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
    $db = config::getConnexion();

    try{
      
                $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
 header('Location: afficheravisf.php');
}
?>
          

      </div>
    </div>
  </div>
  
  <style>
    .contact-address .icon {border-radius:50%;display: inline-block;font-size: 20px;height: 50px;line-height: 50px;margin-bottom: 25px;position: relative;text-align: center;width: 50px;color:#ffffff;}

    .contact-address { float:left;width:100%; }
    
    .contact-form-section .contact-form {background:#ffffff; }
    .contact-address .social-icons li a:hover { background:;border-color:;}
.contact-address .icon-wrapper{padding: 30px 10px;border:1px solid #076cec;float:left;width:100%;}
.contact-address h4 { font-size: 18px;text-transform:uppercase;letter-spacing:1px;color:#263036; }

    .contact-address .icon {background: #076cec;}
  </style>
  
  
</div>






</div>
  </div>
</div>
	
             <div class="dt-sc-hr-invisible-large"></div>
          </div>  
        </div>
      </div>
      
      
    
  </main>
<?php
include('includes/footer.php');

?>
