<?php 
include_once("inc/db_connect.php");
include("exportrating.php");
include("inc/header.php"); 
?>
<title>Exporting Data to Excel using PHP & MySQL</title>
<?php include('inc/container.php');?>
<div class="container">	
	<h2><center> Exporting Data to Excel</center></h2>
	<div class="well-sm col-sm-12">
		<div class="btn-group pull-right">	
			<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">					
				<button type="submit" id="dataExport" name="dataExport" value="Export to excel" class="btn btn-info">Export To Excel</button>
			</form>
		</div>
	</div>				  
	<table id="" class="table table-striped table-bordered">
		<tr>
			<th>Rating ID</th>
			<th>Business ID</th>
			<th>Rating</th>
	
			
		</tr>
		<tbody>
			<?php foreach($developersData as $developer) { ?>
			   <tr>
			   <td><?php echo $developer ['rating_id']; ?></td>
			   <td><?php echo $developer ['business_id']; ?></td>
			   <td><?php echo $developer ['rating']; ?></td>  

			   </tr>
			<?php } ?>
		</tbody>
    </table>		
</div>
<?php include('inc/footer.php');?>




