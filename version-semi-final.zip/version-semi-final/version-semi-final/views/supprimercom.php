<?PHP
include "../core/commandeC.php";
$commandeC=new commandeC();
if (isset($_POST["id"])){
  $commandeC->supprimercommande($_POST["id"]);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A command has been Deleted', 'unread', CURRENT_TIMESTAMP, 'affichercom.php');";
  $db = config::getConnexion();

  try{
  
          $req=$db->prepare($sql);

    $req->execute();

     
  }
    catch (Exception $e){
    echo 'Erreur: '.$e->getMessage();
  }
  header('Location: affichercom.php');
}

?>