function verifier() 
{
    var errors ="";

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 )
    {

        errors += "a"; 

      }

    if(document.myform.nom.value=="")
    {
        errors += "b";
    }

    if(document.myform.prenom.value=="" )
    {
        errors += "c";
    }
     if(document.myform.date.value=="")
    {
        errors += "d";
    }
     if(document.myform.tache.value=="")
    {
        errors += "e";
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    }