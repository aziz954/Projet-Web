function verifier() {
    var errors ="";
   
    
    if(document.myform.id.value==""){
    
        errors += "a";
    
    }

    if(document.myform.adr.value==""){
    
        errors += "b";
    

        
    }

    if(document.myform.heure.value==""){
    
        errors += "b";
    
    }

    if(document.myform.datee.value==""){
    
        errors += "b";
    
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        errors += "c";
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }

