
<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/commandeC.php";
$c1C=new commandeC();
$listec=$c1C->affichercommandes();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id_cl as id_cl FROM client");
?>
<script language="javascript"type="text/javascript" src="veri.js"></script>
<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">ADDING Commande Boys</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">ADDING Commande </li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
          <form action="ajoutcom.php" method="GET" id ="myform">
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-user-circle-o"></i>
            Gestion Commande
                </h4>

                 <div class="form-group">
                <label> ID </label>
                  <input type="text" minlength="8" maxlength="8" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
                <label>ID DU CLIENT</label>
                <select name="id_cl"id="id_cl">
                
<?php
while($rows = $result->fetch_assoc())
{
$id_cl=$rows['id_cl'];
echo"<option value='$id_cl'>$id_cl</option>";
}
?>
                </select>
            </div>
            <div class="form-group">
                <label>QuantitE </label>
                <input type="number" name="q" class="form-control" placeholder="Enter qesse">
            </div>


                <div class="form-footer">
                    <button type="submit" class="btn btn-danger"><i class="fa fa-times"></i> </button>
                    <button  type="submit" class="btn btn-success fa fa-user-plus" name="registerbtn2" onclick="anim5_noti()"></button>
                   
                </div>
              </form>
            </div>
          </div>
        </div>
      </div><!--End Row-->

    
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  

  
  <!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
  
  
   <p class="mb-0">Header Colors</p>
      <hr>
    
    <div class="mb-3">
      <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
    </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
    
      <div class="mb-3">
      <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
    </div>
    
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>

