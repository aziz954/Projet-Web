<?PHP
include "../entities/facture.php";
include "../core/factureC.php";

if (!empty($_GET['id']) and !empty($_GET['mont']) and !empty($_GET['id_com'])and !empty($_GET['id_cl']) and !empty($_GET['datef']) ){
$facture1=new facture($_GET['id'],$_GET['mont'],$_GET['id_com'],$_GET['id_cl'],$_GET['datef']);

$facture1C=new factureC();
$facture1C->ajouter($facture1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A bill has been Added', 'unread', CURRENT_TIMESTAMP, 'afficherfacture.php');";
    $db = config::getConnexion();

    try{
      
                $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
        header('Location:afficherfacture.php?message=<div class="alert alert-success">success</div>');
  
}else{
  if (empty($_GET['id'])){
    header('Location:afficherfacture.php?message=<div class="alert alert-danger">id missing</div>');
  } 
  if (empty($_GET['mont'])){
    header('Location:afficherfacture.php?message=<div class="alert alert-danger">Total missing</div>');
  }
  if (empty($_GET['id_com'])){
    header('Location:afficherfacture.php?message=<div class="alert alert-danger">Id delivery missing</div>');
  }
  if (empty($_GET['id_cl'])){
    header('Location:afficherfacture.php?message=<div class="alert alert-danger">Client id missing</div>');
  }
  if (empty($_GET['datef'])){
    header('Location:afficherfacture.php?message=<div class="alert alert-danger">Date missing</div>');
  }
}
//*/

?>