<?PHP
include "../entities/Fournisseur.php";
include "../core/fournisseurC.php";

if (!empty($_GET['id']) and !empty($_GET['nom']) and !empty($_GET['prenom']) and !empty($_GET['date']) and !empty($_GET['tache'])){
$fournisseur1=new fournisseur($_GET['id'],$_GET['nom'],$_GET['prenom'],$_GET['date'],$_GET['tache']);

$fournisseur1C=new fournisseurC();
$fournisseur1C->ajouterFournisseur($fournisseur1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'fournisseur ajouté ', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";

		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: afficherfournisseur.php?message=<div class="alert alert-success">success</div>');
	
}
else{
  if (empty($_GET['id'])){
    header('Location:afficherfournisseur.php?message=<div class="alert alert-danger">id missing</div>');
  } 
  if (empty($_GET['nom'])){
    header('Location:afficherfournisseur.php?message=<div class="alert alert-danger">nom missing</div>');
  }
  if (empty($_GET['prenom'])){
    header('Location:afficherfournisseur.php?message=<div class="alert alert-danger">prenom missing</div>');
  }
  if (empty($_GET['date'])){
    header('Location:afficherfournisseur.php?message=<div class="alert alert-danger">date missing</div>');
  }
if (empty($_GET['tache'])){
    header('Location:afficherfournisseur.php?message=<div class="alert alert-danger">tache missing</div>');
}
}
//*/

?>