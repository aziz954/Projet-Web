<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM livraison 
	WHERE id LIKE '%".$search."%'
	OR ref LIKE '%".$search."%' 
	OR adr LIKE '%".$search."%' 
	OR heure LIKE '%".$search."%' 
	OR datee LIKE '%".$search."%'
	";
}
else
{
	$query = "
	SELECT * FROM livraison ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '  
   
 <table class="table table-bordered">  
      <tr>  
           <th>ID</th>  
           <th>Reference</th>  
           <th>Adresse</th>  
           <th>Time</th>  
           <th>Date</th> 
          <td align="center" colspan="2">Actions</td> 

      </tr>  

 ';  

	while($row = mysqli_fetch_array($result))
	{
	 $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["ref"] . '</td>  
           <td>' . $row["adr"] . '</td>  
           <td>' . $row["heure"] . '</td>  
           <td>' . $row["datee"] . '</td> 
             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="register_editliv.php?id= ' . $row["id"] . ' " class ="btn btn-primary fa fa-edit">
    </a>
      </td>
  <td>

        <form action ="supprimerliv.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2"  class="delete_btn_ajax btn btn-primary fa fa-trash"></i></button>
      </form>
      </td>
      </tr>  
      ';  
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>