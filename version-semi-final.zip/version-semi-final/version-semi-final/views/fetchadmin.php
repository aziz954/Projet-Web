<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM register 
	WHERE id LIKE '%".$search."%'
	OR usertype LIKE '%".$search."%' 
	OR username LIKE '%".$search."%' 
	OR email LIKE '%".$search."%'
    OR password LIKE '%".$search."%' 
      OR image LIKE '%".$search."%' 

 
	";
}
else
{
	$query = "
	SELECT * FROM register ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '  
   
 <table class="table table-bordered">  
      <tr>  
           <th>id</th>  
           <th>usertype</th>  
           <th>username</th>  
           <th>email</th>  
            <th>password</th>  
           <th>image</th>  

<td align="center" colspan="2">Actions</td> 
      </tr>  

 ';  

	while($row = mysqli_fetch_array($result))
	{
	 $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["usertype"] . '</td>  
           <td>' . $row["username"] . '</td>  
           <td>' . $row["email"] . '</td> 
           <td>' . $row["password"] . '</td>  
           <td>' . $row["image"] . '</td>  

 
<td align="center">
              
         <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="editadmin.php?id= ' . $row["id"] . ' " class ="btn btn-primary fa fa-edit">
    </a>
      </td>
  <td>

        <form action ="supprimeradmin.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2"  class="delete_btn_ajax btn btn-primary fa fa-trash"></i></button>
      </form>
      </td>
      </tr>  
      ';  
  }
  echo $output;
}
else
{
  echo 'Data Not Found';
}
?>