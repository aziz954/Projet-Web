<?PHP
include "../core/ratingC.php";
$ratingC=new ratingC();
if (isset($_POST["rating_id"])){
  $ratingC->supprimerrating($_POST["rating_id"]);
      $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A delevryhas been Deleted', 'unread', CURRENT_TIMESTAMP, 'afficherrating.php');";
    $db = config::getConnexion();

    try{
      
                $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: afficherrating.php');
}

?>