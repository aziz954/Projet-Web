<?PHP
include "../entities/rating.php";
include "../core/ratingC.php";

if (!empty($_GET['rating_id']) and !empty($_GET['business_id']) and !empty($_GET['rating'])){
$rating1=new rating($_GET['rating_id'],$_GET['business_id'],$_GET['rating']);

$rating1C=new ratingC();
$rating1C->ajouter($rating1);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery boy has been Added', 'unread', CURRENT_TIMESTAMP, 'afficherrating.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: afficherrating.php?message=<div class="alert alert-success">success</div>');
  
}
else{
  if (empty($_GET['nom'])){
    header('Location:afficherrating.php?message=<div class="alert alert-danger">nom missing</div>');
  } 
  if (empty($_GET['prenom'])){
    header('Location:afficherrating.php?message=<div class="alert alert-danger">prenom missing</div>');
  }
  if (empty($_GET['id'])){
    header('Location:afficherrating.php?message=<div class="alert alert-danger">id missing</div>');
  }
}

?>