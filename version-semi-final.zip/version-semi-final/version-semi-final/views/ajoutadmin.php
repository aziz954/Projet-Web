
 <?PHP
include "../entities/login.php";
include "../core/loginC.php";

if (!empty($_GET['id']) and !empty($_GET['usertype']) and !empty($_GET['username']) and !empty($_GET['email']) and !empty($_GET['password']) ){
$target_file = $_FILES["photo"];

$log1=new log($_GET['id'],$_GET['usertype'],$_GET['username'],$_GET['email'],$_GET['password'],null);

$log1C=new logC();
$log1C->ajouter($log1, $target_file);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery2 has been Added', 'unread', CURRENT_TIMESTAMP, 'afficheradmin.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: afficheradmin.php ?message=<div class="alert alert-success">success</div>');
    
}
else{
  if (empty($_GET['id'])){
    header('Location:afficheradmin.php?message=<div class="alert alert-danger">nom missing</div>');
  } 
  if (empty($_GET['usertype'])){
    header('Location:afficheradmin.php?message=<div class="alert alert-danger">prenom missing</div>');
  }
  if (empty($_GET['username'])){
    header('Location:afficheradmin.php?message=<div class="alert alert-danger">id missing</div>');
  }
  if (empty($_GET[' email'])){
    header('Location:afficheradmin.php?message=<div class="alert alert-danger">id missing</div>');
  }
   if (empty($_GET[' password'])){
    header('Location:afficheradmin.php?message=<div class="alert alert-danger">id missing</div>');
  }
 
}


?>

