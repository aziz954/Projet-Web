<?PHP
include "../core/productC.php";
$productC=new productC();
if (isset($_POST["id"])){
  $productC->supprimerproduct($_POST["id"]);
  header('Location: afficherproduct.php');
}

?>