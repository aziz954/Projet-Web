<?PHP
include "../config.php";
class livC {
function afficher ($liv){
		echo "id: ".$liv->getid()."<br>";
		echo "ref: ".$liv->getref()."<br>";
		echo "adr: ".$liv->getadr()."<br>";
		echo "heure: ".$liv->getheure()."<br>";
		echo "datee".$liv->getdatee()."<br>";
	}
	
	function ajouter($liv){
		$sql="insert into livraison (id,ref,adr,heure,datee)
 values (:id, :ref,:adr,:heure,:datee)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$liv->getid();
        $ref=$liv->getref();
        $adr=$liv->getadr();
        $heure=$liv->getheure();
        $datee=$liv->getdatee();
		$req->bindValue(':id',$id);
		$req->bindValue(':ref',$ref);
		$req->bindValue(':adr',$adr);
		$req->bindValue(':heure',$heure);
		$req->bindValue(':datee',$datee);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherliv(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From livraison";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerliv($id){
		$sql="DELETE FROM livraison where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierliv($liv,$id){
		$sql="UPDATE livraison SET id=:id, ref=:ref,adr=:adr,heure=:heure,datee=:datee WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$liv->getid();
        $ref=$liv->getref();
        $adr=$liv->getadr();
        $heure=$liv->getheure();
        $datee=$liv->getdatee();
		$datas = array(':id'=>$id, ':ref'=>$ref, ':adr'=>$adr,':heure'=>$heure,':datee'=>$datee);
		$req->bindValue(':id',$id);
		$req->bindValue(':ref',$ref);
		$req->bindValue(':adr',$adr);
		$req->bindValue(':heure',$heure);
		$req->bindValue(':datee',$datee);
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererliv($id){
		$sql="SELECT * from livraison where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeEmployes($tarif){
		$sql="SELECT * from livraison where tarifHoraire=$tarif";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
