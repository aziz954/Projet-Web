<?PHP
include "../entities/livraison.php";
include "../core/livraisonC.php";

if (isset($_GET['id']) and isset($_GET['ref']) and isset($_GET['adr']) and isset($_GET['heure']) and isset($_GET['datee'])){
$liv1=new liv($_GET['id'],$_GET['ref'],$_GET['adr'],$_GET['heure'],$_GET['datee']);

$liv1C=new livC();
$liv1C->ajouter($liv1);
header('Location: gestionliv.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Delivery is Not Added";
            header('Location: gestionliv.php');
}
//*/

?>