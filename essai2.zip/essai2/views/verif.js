function verifier() {

    if(document.myform.nom.value.length = 0){
    
        errors += "";
    
    }
    
    if(document.myform.prenom.value.length =0){
    
        errors += "a <br>";
    
    }
    
    if(document.myform.adresse.value.length =0){
    
        errors += "b <br>";
    
    }
    
    if(document.myform.num.value.length = 0){
    
        errors += "";
    
    }

     if(document.myform.id.value.length = 0){
    
        errors += "";
    
    }
    
    if(document.myform.q.value.length =0){
    
        errors += "Quantite <br>";
        alert("Quantite OBLIGATOIRE");
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }