<?PHP
include "../core/clientC.php";
$clientC=new clientC();
if (isset($_POST["id"]))
{
  $clientC->supprimerclient($_POST["id"]);
  	  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A client has been Deleted', 'unread', CURRENT_TIMESTAMP, 'gestionclient.php');";

		$db = config::getConnexion();

		try
    {
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: gestionclient.php');
}

?>