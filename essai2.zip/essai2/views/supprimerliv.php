<?PHP
include "../core/livraisonC.php";
$livC=new livC();
if (isset($_POST["id"])){
  $livC->supprimerliv($_POST["id"]);
  header('Location: gestionliv.php');
}

?>