<?php
/**
 * 
 */
 

class liv
{
	
	private $id;
	private $ref;
	private $adr;
	private $heure;
	private $datee;
	public function getid(){
		return $this->id;

	}
	public function getref()
	{
		return $this->ref;

	}
	public function getadr()
	{
		return $this->adr;

	}
	public function getheure()
	{
		return $this->heure;
	}
	public function getdatee()
	{
		return $this->datee;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	public function setref($ref)
	{

		$this->ref=$ref;
	}
	public function setadr($adr)
	{

		$this->adr=$adr;
	}
	public function setheure($heure)
	{

		$this->heure=$heure;
	}
	public function setdatee($datee)
	{

		$this->datee=$datee;
	}
	public function construct()
	{
		$this->id=0;
		$this->ref=0;
		$this->adr="";
		$this->heure=0;


	}
	public function __construct($id,$ref,$adr,$heure,$datee)
	{

		$this->id=$id;
		$this->ref=$ref;
		$this->adr=$adr;
		$this->heure=$heure;
		$this->datee=$datee;
	}
	
}

?>


