<?php
require_once "google-api/vendor/autoload.php";
$gClient = new Google_Client();
$gClient->setClientId("351005299323-67nc316ar9fnv31o2baql5feibre5f4h.apps.googleusercontent.com");
$gClient->setClientSecret("fYqrPZf8bZ6le-PA2JM_KZ3D");
$gClient->setApplicationName("Vicode Media Login");
$gClient->setRedirectUri("http://localhost/login-with-google-master/");
$gClient->addScope("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");

// login URL
$login_url = $gClient->createAuthUrl();
?>