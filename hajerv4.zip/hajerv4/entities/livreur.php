<?php
/**
 * 
 */
 

class livr
{
	
	private $nom;
	private $prenom;
	private $id;
	private $idliv;

	public function getnom(){
		return $this->nom;

	}
	
	public function getprenom()
	{
		return $this->prenom;

	}
	public function getid()
	{
		return $this->id;
	}
	public function getidliv()
	{
		return $this->idliv;

	}
	public function setnom($nom)
	{

		$this->nom=$nom;
	}
	public function setprenom($prenom)
	{

		$this->prenom=$prenom;
	}
	public function setid($id)
	{

		$this->id=$id;
	}
	public function setidliv($idliv)
	{

		$this->idliv=$idliv;
	}
	
	public function construct()
	{
		$this->nom="";
		$this->prenom="";
		$this->id=0;
		$this->idliv=0;


	}
	public function __construct($nom,$prenom,$id,$idliv)
	{

		$this->nom=$nom;
		$this->prenom=$prenom;
		$this->id=$id;
		$this->idliv=$idliv;
		
	}
	
}

?>


