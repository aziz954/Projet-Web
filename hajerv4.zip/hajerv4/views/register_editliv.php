
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/livraison.php";
include "../core/livraisonC.php";
if (isset($_GET['id'])){
    $livC=new livC();
    $result=$livC->recupererliv($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $ref=$row['ref'];
        $adr=$row['adr'];
        $heure=$row['heure'];
        $datee=$row['datee'];
       $mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM vendeurs");
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT DELIVERIES </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
            <div class="form-group">
                <label>Reference</label>
                       <select name="ref">
<?php
while($rows = $result->fetch_assoc())
{
$id=$rows['id'];
echo"<option value='$id'>$id</option>";
}
?>
                </select>
            </div>
            <div class="form-group">
                <label>Adresse</label>
                <input type="text" name="adr"  value="<?php echo $row['adr']; ?>"class="form-control" placeholder="Enter Adresse">
            </div >
            <div class="form-group">
                <label> Time </label>
                 <input type="text" name="heure"   value="<?php echo $row['heure']; ?>"class="form-control" placeholder="Enter Time">
            </div>
            <div class="form-group">
                <label> Date </label>
                 <input type="date" name="datee"  value="<?php echo $row['datee']; ?>"class="form-control" placeholder="Enter Date">
            </div>
            <a href="gestionliv.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary ">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $liv=new liv($_POST['id'],$_POST['ref'],$_POST['adr'],$_POST['heure'],$_POST['datee']);
    $livC->modifierliv($liv,$_POST['edit_id']);

      $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Deleviry has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    echo '<meta http-equiv="refresh" content="0; URL=gestionliv.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
