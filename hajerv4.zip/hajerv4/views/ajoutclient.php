<?PHP
include "../entities/client.php";
include "../core/clientC.php";

if (isset($_GET['nom']) and isset($_GET['prenom']) and isset($_GET['adresse'])and isset($_GET['num'])and isset($_GET['id'])){
$client1=new client($_GET['nom'],$_GET['prenom'],$_GET['adresse'],$_GET['num'],$_GET['id']);

$client1C=new clientC();
$client1C->ajouter($client1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A client has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionclient.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionclient.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Client is Not Added";
            header('Location: gestionclient.php');
}
//*/

?>