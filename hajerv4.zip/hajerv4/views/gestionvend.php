<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/vendeurC.php";
$ven1C=new venC();
$listeven=$ven1C->afficherven();
$mysqli=NEW MySQLi('localhost','root','','medline');

?>
<script language="javascript"type="text/javascript" src="verif_vend.js"></script>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add VENDEURS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form  name="myform" action="ajoutven.php" method="GET" >

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="text" minlength="8" maxlength="8" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
                <label>Nom</label>
                <input type="text" name="nom" class="form-control" placeholder="Enter Nom">
            </div>
            <div class="form-group">
                <label>Prenom</label>
                <input type="text" name="prenom" class="form-control" placeholder="Enter Prenom">
            </div>
            <div class="form-group">
                <label>Num</label>
                <input type="times" name="num" class="form-control" placeholder="Enter Num">
            </div>
        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary" onclick="verifier()">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<form method="POST">
   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Vendeurs Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add Vendeurs Profile 
            </button>
             <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">Print</button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                                                </script>
   <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

  <button type="submit"name="tric"id="close-image"><img src="img/lcroi.png"></button>
<button type="submit" name="trid"id="close-image"><img src="img/ldesc.png"></button>
    </h6>
  </div>
</form>
  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
            <th> NOM </th>
            <th>PRENOM </th>
            <th>NUM</th>
         
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
              <?php

         
if (isset($_POST['trid'])){
   $listeven=$ven1C->tridesc();
 foreach($listeven as $row){

?>
<tr>
       <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['nom']; ?> </td>
      <td><?php echo $row['prenom']; ?> </td>
      <td><?php echo $row['num']; ?> </td>
      <td>
        <input type="hidden" name ="edit_id3" value="<?php echo $row['id']; ?>">

     <a href="register_editven.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerven.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn3" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>
         <?php

 if  (isset($_POST['tric'])){
   $listeven=$ven1C->tri();
 foreach($listeven as $row){

?>
<tr>
       <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['nom']; ?> </td>
      <td><?php echo $row['prenom']; ?> </td>
      <td><?php echo $row['num']; ?> </td>
      <td>
        <input type="hidden" name ="edit_id3" value="<?php echo $row['id']; ?>">

     <a href="register_editven.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerven.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn3" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>
     
             <?php
  if (isset($_POST['submit'])){
   $listeven=$ven1C->rechercherListeven($_POST['search']);
  foreach($listeven as $row){

?>
<tr>
       <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['nom']; ?> </td>
      <td><?php echo $row['prenom']; ?> </td>
      <td><?php echo $row['num']; ?> </td>
      <td>
        <input type="hidden" name ="edit_id3" value="<?php echo $row['id']; ?>">

     <a href="register_editven.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerven.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn3" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
    <?php
  }
}
     ?>
    <?php
     $page1=0;
     if (isset($_GET['page'])){
     $page=$_GET["page"];
if($page=="" || $page=="1")
{
  $page1=0;
}
else
{
  $page1=($page*5)-5;
}
}
$res=mysqli_query($mysqli,"SELECT * FROM vendeurs limit $page1,5 ");
while($row=mysqli_fetch_array($res))
{

 
  
    ?>
    <tr>
      <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['nom']; ?> </td>
      <td><?php echo $row['prenom']; ?> </td>
      <td><?php echo $row['num']; ?> </td>
   
      <td>
       
          <input type="hidden" name ="edit_id3" value="<?php echo $row['id']; ?>">

     <a href="register_editven.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
        <form action ="supprimerven.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <button type="submit"name ="delete_btn3" class ="btn btn-danger">DELETE</button>
      </form>
      </td>
    </tr>
     <?php
}

  $res1=mysqli_query($mysqli,"SELECT * FROM vendeurs  ");
  $cou=mysqli_num_rows($res1);
  $a=$cou/5;
  $a=ceil($a);
  echo"<br>"; echo"<br>";
  for($b=1;$b<=$a;$b++)
  {
    ?><a href="gestionvend.php?page=<?php echo $b ?>"class='btn btn-primary'style="text -decoration:none"><?php echo $b." "; ?></a><?php
  }
 


     ?>
          
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>