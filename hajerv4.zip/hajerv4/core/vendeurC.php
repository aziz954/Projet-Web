<?PHP
include "../config.php";
class venC {
function afficher ($ven){
		echo "id: ".$ven->getid()."<br>";
		echo "nom: ".$ven->getnom()."<br>";
		echo "prenom: ".$ven->getprenom()."<br>";
		echo "num: ".$ven->getnum()."<br>";
	}
	
	function ajouter($ven){
		$sql="insert into vendeurs (id,nom,prenom,num)
 values (:id, :nom,:prenom,:num)";
		$db = config::getConnexion();
		try{
        $req=$db->prepare($sql);
        $id=$ven->getid();
        $nom=$ven->getnom();
        $prenom=$ven->getprenom();
        $num=$ven->getnum();
      
		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':num',$num);
		
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherven(){
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From vendeurs";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerven($id){
		$sql="DELETE FROM vendeurs where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifierven($ven,$id){
		$sql="UPDATE vendeurs SET id=:id, nom=:nom,prenom=:prenom,num=:num WHERE id=:id";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
        $req=$db->prepare($sql);
		$id=$ven->getid();
        $nom=$ven->getnom();
        $prenom=$ven->getprenom();
        $num=$ven->getnum();
        
		$datas = array(':id'=>$id, ':nom'=>$nom, ':prenom'=>$prenom,':num'=>$num);

		$req->bindValue(':id',$id);
		$req->bindValue(':nom',$nom);
		$req->bindValue(':prenom',$prenom);
		$req->bindValue(':num',$num);
		
		
		
		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererven($id){
		$sql="SELECT * from vendeurs where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeven($id){
		$sql="SELECT * from vendeurs where id=$id";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tridesc(){
		$sql="SELECT * from vendeurs ORDER BY id DESC";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function tri(){
		$sql="SELECT * from vendeurs ORDER BY id ";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
