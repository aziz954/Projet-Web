<?PHP
include "../entities/livreur.php";
include "../core/livreurC.php";

if (!empty($_GET['nom']) and !empty($_GET['prenom']) and !empty($_GET['id']) and !empty($_GET['idliv']) ){
$livr1=new livr($_GET['nom'],$_GET['prenom'],$_GET['id'],$_GET['idliv']);

$livr1C=new livrC();
$livr1C->ajouter($livr1);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery boy has been Added', 'unread', CURRENT_TIMESTAMP, 'afficherlivreur.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: afficherlivreur.php?message=<div class="alert alert-success">success</div>');
  
}
else{
  if (empty($_GET['nom'])){
    header('Location:afficherlivreur.php?message=<div class="alert alert-danger">nom missing</div>');
  } 
  if (empty($_GET['prenom'])){
    header('Location:afficherlivreur.php?message=<div class="alert alert-danger">prenom missing</div>');
  }
  if (empty($_GET['id'])){
    header('Location:afficherlivreur.php?message=<div class="alert alert-danger">id missing</div>');
  }
}

?>