
<?php
//include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 
include "../entities/fourniture.php";
include "../core/fournitureC.php";
if (isset($_GET['id'])){
    $fournitureC=new fournitureC();
    $result=$fournitureC->recupererfourniture($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $nom=$row['nom'];
        $quantite=$row['quantite'];
        $fournisseur=$row['fournisseur'];
        $mysqli=NEW MySQLi('localhost','root','','medline');
        $result=$mysqli->query("SELECT id as fournisseur FROM fournisseur");
        ?>
        <script language="javascript"type="text/javascript" src="verificationf.js"></script>

<!--End topbar header-->
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Editing Delevries Form</h4>
		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editing Delevries </li>
         </ol>
	   </div>
	   <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->


  

		  <div class="row">
			<div class="col-lg-12">
			   
			 
       <div class="card">
        <form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

   <div class="form-group">
                <label> ID </label>
                 <input type="number" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
           
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="nom"  value="<?php echo $row['nom']; ?>"class="form-control" placeholder="Enter Name">
            </div >
            <div class="form-group">
                <label>Quantity</label>
                 <input type="number" name="quantite"   value="<?php echo $row['quantite']; ?>"class="form-control" placeholder="Enter Quantity">
            </div>
            
            <div class="form-group">
                <label>fournisseur</label>
                <select name="fournisseur"id="fournisseur">
                        <?php
                          while($rows = $result->fetch_assoc())
                          {
                              $fournisseur=$rows['fournisseur'];
                                  echo"<option value='$fournisseur'>$fournisseur</option>";
                          }
                        ?>
                </select>
            </div>
 
         
                <div class="form-footer">
                      <a href="afficherfourniture.php" class="btn btn-danger fa fa-mail-reply"></a>
                    <button  type="submit" class="btn btn-success fa fa-edit" name="updatebtn2" onclick="anim5_noti()"></button>
                   
                </div>
          </form>
         </div>
         </div>

			</div>
            <?PHP

   }

     }  
          
    if (isset($_POST['updatebtn2'])and !empty($_POST['nom'])and !empty($_POST['quantite'])){
    
    $fourniture=new fourniture($_POST['id'],$_POST['nom'],$_POST['quantite'],$_POST['fournisseur']);
    $fournitureC->modifierfourniture($fourniture,$_POST['edit_id']);
    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Product has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionlivreur.php');";
    $db = config::getConnexion();

    try{
  
                    $req=$db->prepare($sql);

        $req->execute();
       
    }
      catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
    echo '<meta http-equiv="refresh" content="0; URL=afficherfourniture.php">';
}
?>
		  </div><!--End Row-->
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2019 Bulona Admin
        </div>
      </div>
    </footer>
	<!--End footer-->
	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
	
	
	 <p class="mb-0">Header Colors</p>
      <hr>
	  
	  <div class="mb-3">
	    <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
	  </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
	  
      <div class="mb-3">
	    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
	  </div>
	  
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->

<?php
include('includes/scripts.php'); 
include('includes/footer.php'); 


        ?>