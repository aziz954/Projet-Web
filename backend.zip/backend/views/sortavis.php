<?php  
 //sort.php  
include "../core/avisC.php";
$avis1C=new avisC();
$listeavis=$avis1C->afficherAvis();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id_cl as id_client FROM avis");
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM avis ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
  <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/avis.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>PDF</span>

  </a>
   <a href="exel/indexavis.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>EXEL</span>

  </a>
  

                                   <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span>PRINT</span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  
   
        </div>


      </div>
<table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id_client" data-order="'.$order.'" href="#">ID Client</a></th>  
           <th><a class="column_sort" id="type" data-order="'.$order.'" href="#">Type</a></th>  
           <th><a class="column_sort" id="avis" data-order="'.$order.'" href="#">Avis</a></th>  
              <td align="center" colspan="2">Actions</td> 
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id_client"] . '</td>  
           <td>' . $row["type"] . '</td>  
           <td>' . $row["avis"] . '</td>  
  <td align="center">

        <form action ="supprimeravis.php" method="POST">
<input type="hidden" name="id" value=' . $row["id_client"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-tresh-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>   