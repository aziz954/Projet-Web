<?PHP
include "../core/livreurC.php";
$livrC=new livrC();
if (isset($_POST["id"])){
  $livrC->supprimerlivr($_POST["id"]);
      $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A delevryhas been Deleted', 'unread', CURRENT_TIMESTAMP, 'afficherlivreur.php');";
    $db = config::getConnexion();

    try{
      
                $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: afficherlivreur.php');
}

?>