
<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php');  
include "../core/productC.php";
$product1C=new productC();
$listeproduct=$product1C->afficherproduct();
$mysqli=NEW MySQLi('localhost','root','','medline');
?>
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">ADDING DELIVRIES</h4>
		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">ADDING DELIVRIES</li>
         </ol>
	   </div>
	   <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
          <form action="ajoutproduct.php" method="GET" id ="myform">
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-user-circle-o"></i>
            Gestion product
                </h4>

                <div class="form-group row">
                  <label for="input-1" class="col-sm-2 col-form-label">ID</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-1" name="id" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-2" class="col-sm-2 col-form-label">pname</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-2" name="pname" required>
                  </div>
                </div>


                <div class="form-group row">
                  <label for="input-3" class="col-sm-2 col-form-label">image</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-3" name="image" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">pprice</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-4" name="pprice">
                  </div>
                </div>
               
                <div class="form-group row">
                  <label for="input-5" class="col-sm-2 col-form-label">Quantity </label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-5" name="Quantity" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-6" class="col-sm-2 col-form-label">description</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-6" name="description" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-7" class="col-sm-2 col-form-label">pmaterial</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-7" name="pmaterial" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-8" class="col-sm-2 col-form-label">pbrand</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-8" name="pbrand" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-9" class="col-sm-2 col-form-label">pcolor</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-9" name="pcolor" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-10" class="col-sm-2 col-form-label">IDC</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-10" name="IDC" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-11" class="col-sm-2 col-form-label">price</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-11" name="price" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-12" class="col-sm-2 col-form-label">material</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-12" name="material" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-13" class="col-sm-2 col-form-label">color</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-13" name="color" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-14" class="col-sm-2 col-form-label">brand</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-14" name="brand" required>
                  </div>
                </div>

                <div class="form-group row">
                  <label for="input-15" class="col-sm-2 col-form-label">type</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-15" name="type" required>
                  </div>
                </div>


               
               
                <div class="form-footer">
                    <button type="submit" class="btn btn-danger"><i class="fa fa-times"></i> </button>
                    <button  type="submit" class="btn btn-success fa fa-user-plus" name="registerbtn2" onclick="anim5_noti()"></button>
                   
                </div>
              </form>
            </div>
          </div>
        </div>
      </div><!--End Row-->

    
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	

	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
	
	
	 <p class="mb-0">Header Colors</p>
      <hr>
	  
	  <div class="mb-3">
	    <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
	  </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
	  
      <div class="mb-3">
	    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
	  </div>
	  
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>

