function verifie() {
    var errors ="";


    if(document.myform.mont.value==""){
    
        errors += "b";
        <div class='alert alert-danger'>Insert montant</div>
    
    }

    if(document.myform.datef.value==""){
    
        errors += "b";
        <div class='alert alert-danger'>Insert date</div>
    
    }

    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    else {
        <div class='alert alert-success'>Success</div>
    }
    
    }

