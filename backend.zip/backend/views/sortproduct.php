<?php  
 //sort.php  
include "../core/productC.php";
$product1C=new productC();
$listeproduct=$product1C->afficherproduct();
$mysqli=NEW MySQLi('localhost','root','','medline');
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM product ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
  <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/product.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>PDF</span>

  </a>
   <a href="exel/indexproduct.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>EXEL</span>

  </a>
  

                                   <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span>PRINT</span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  
   
        </div>


      </div>
<table class="table table-bordered">  
       <tr>
         <th> <a class="column_sort" id="id" data-order="desc" href="#">ID</a></th>
            <th><a class="column_sort" id="pname" data-order="desc" href="#">Produit name</a>  </th>
            <th><a class="column_sort" id="image" data-order="desc" href="#">Image</a>  </th>
            <th><a class="column_sort" id="pprice" data-order="desc" href="#">pprice</a>  </th>
            <th><a class="column_sort" id="Quantity" data-order="desc" href="#">Quantity</a>  </th>
            <th><a class="column_sort" id="description" data-order="desc" href="#">description</a>  </th>
            <th><a class="column_sort" id="pmaterial" data-order="desc" href="#">pmaterial</a>  </th>
            <th><a class="column_sort" id="pbrand" data-order="desc" href="#">pbrand</a>  </th>
            <th><a class="column_sort" id="pcolor" data-order="desc" href="#">pcolor</a>  </th>
            <th><a class="column_sort" id="IDC" data-order="desc" href="#">IDC</a>  </th>
            <th><a class="column_sort" id="price" data-order="desc" href="#">price</a>  </th>
            <th><a class="column_sort" id="material" data-order="desc" href="#">material</a>  </th>
            <th><a class="column_sort" id="color" data-order="desc" href="#">color</a> </th>
            <th><a class="column_sort" id="brand" data-order="desc" href="#">brand</a></th>
            <th><a class="column_sort" id="type" data-order="desc" href="#">type</a></th>
            <td align="center" colspan="2">Actions</td>
                    </tr> 
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["pname"] . '</td>  
           <td>' . $row["image"] . '</td>  
           <td>' . $row["pprice"] . '</td>  
          <td>' . $row["Quantity"] . '</td>  
           <td>' . $row["description"] . '</td> 
            <td>' . $row["pmaterial"] . '</td>  
           <td>' . $row["pbrand"] . '</td>  
           <td>' . $row["pcolor"] . '</td>  
           <td>' . $row["IDC"] . '</td>  
           <td>' . $row["price"] . '</td>  
           <td>' . $row["material"] . '</td>  
           <td>' . $row["color"] . '</td> 
            <td>' . $row["brand"] . '</td>  
           <td>' . $row["type"] . '</td>  
 <td align="center">
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierproduct.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
  <i class="fas fa-edit"></i></a>
      </td>
  <td align="center">

        <form action ="supprimerproduct.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-tresh-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>   