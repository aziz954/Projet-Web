
<?php
//include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/facture.php";
include "../core/factureC.php";
if (isset($_GET['id'])){
    $factureC=new factureC();
    $result=$factureC->recupererfacture($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $mont=$row['mont'];
        $id_com=$row['id_com'];
        $id_cl=$row['id_cl'];
        $datef=$row['datef'];
        $mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id_cl FROM client");
$result1=$mysqli->query("SELECT id as id_com FROM commande");
        ?>
<script language="javascript"type="text/javascript" src="veriffact.js"></script>

<!--End topbar header-->
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
		    <h4 class="page-title">Editing Delevries Form</h4>
		    <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editing Delevries </li>
         </ol>
	   </div>
	   <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->


  

		  <div class="row">
			<div class="col-lg-12">
			   
			 
       <div class="card">
        <form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

    <div class="form-group">
                <label> ID </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter id" readonly>
            </div>
            <div class="form-group">
                <label>Montant</label>
                <input type="text" name="mont" value="<?php echo $row['mont']; ?>" class="form-control" placeholder="Enter montant">
            </div>
            <div class="form-group">
                <label>ID commande</label>
                <select name="id_com"id="id_com">
                
<?php
while($rows = $result1->fetch_assoc())
{
$id_com=$rows['id_com'];
echo"<option value='$id_com'>$id_com</option>";
}
?>
                </select>
            </div >
            <div class="form-group">
                <label> ID client </label>
                <select name="id_cl">
                
<?php
while($rows = $result->fetch_assoc())
{
$id_cl=$rows['id_cl'];
echo"<option value='$id_cl'>$id_cl</option>";
}
?>
</select>
            </div>
            <div class="form-group">
                <label> Date </label>
                 <input type="date" name="datef"  value="<?php echo $row['datef']; ?>"class="form-control" placeholder="Enter Date">
            </div>
         
                <div class="form-footer">
                    <a href="afficherfacture.php" class="btn btn-danger fa fa-mail-reply"></a>
                    <button  type="submit" class="btn btn-success fa fa-edit" name="updatebtn2" onclick="anim5_noti()"></button>
                   
                </div>
          </form>
         </div>
         </div>

			</div>
            <?PHP

   }

     }  
          
    if (isset($_POST['updatebtn2'])and !empty($_POST['mont'])and !empty($_POST['datef'])){
    
    $facture=new facture($_POST['id'],$_POST['mont'],$_POST['id_com'],$_POST['id_cl'],$_POST['datef']);
    $factureC->modifierfacture($facture,$_POST['edit_id']);

    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Bill has been Modified', 'unread', CURRENT_TIMESTAMP, 'afficherfacture.php');";
    $db = config::getConnexion();

    try{
  
                    $req=$db->prepare($sql);

        $req->execute();
       
    }
      catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }
    echo '<meta http-equiv="refresh" content="0; URL=afficherfacture.php">';
}
?>
		  </div><!--End Row-->
<!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2019 Bulona Admin
        </div>
      </div>
    </footer>
	<!--End footer-->
	
	<!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
	
	
	 <p class="mb-0">Header Colors</p>
      <hr>
	  
	  <div class="mb-3">
	    <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
	  </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
	  
      <div class="mb-3">
	    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
	  </div>
	  
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->

<?php
include('includes/scripts.php'); 
include('includes/footer.php'); 


        ?>