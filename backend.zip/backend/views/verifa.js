function verifier() {
    var errors ="";
            
        if(document.myform.id.value==""){
        
            errors += "a";
            <div class='alert alert-danger'>Insert id</div>
        
        }
    
        if(document.myform.mont.value==""){
        
            errors += "b";
            <div class='alert alert-danger'>Insert montant</div>
        
        }

        if(document.myform.date.value=="0000-00-00"){
        
            errors += "b";
            <div class='alert alert-danger'>Insert date</div>
        
        }
    
        if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
            errors += "c";
            <div class='alert alert-danger'>Id doit etre de longueur 8</div>
        
        }
        
        if(errors!="") {
            document.getElementById('erreur').innerHTML = errors;
            return false;
        }
        else {
            <div class='alert alert-success'>Success</div>
        }
        
    
    
    }

