function verifier() {
    var errors ="";
   
    
    if(document.myform.id.value==""){
    
        errors += "a";
    
    }

    if(document.myform.nom.value==""){
    
        errors += "b";
    

        
    }

    if(document.myform.prenom.value==""){
    
        errors += "b";
    
    }
    
    if(document.myform.num.value==""){
    
        errors += "b";
    
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        errors += "c";
    
    }

    if(document.myform.num.value.length < 8 || document.myform.num.value.length > 8 ){
        errors += "c";
    
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    
    }

