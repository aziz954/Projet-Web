<?php
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/loginC.php";
$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
<script src="https://www.amcharts.com/lib/3/serial.js"></script>
<script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
<script src="https://www.amcharts.com/lib/3/plugins/dataloader/dataloader.min.js"></script>
<script src="https://www.amcharts.com/lib/3/maps/js/worldLow.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

 <script src="jquery-3.5.0.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  

<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Data Tables</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Data Tables</li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
   

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Delevries Data </div>
            <div class="card-body">
              <div class="table-responsive"id="employee_table">
                  <div id="example" class="dataTables_wrapper container-fluid dt-bootstrap4">
      <div class="row">
        <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/admin.php"class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-file-pdf-o"tabindex="0"aria-controls="example"type="button">
    <span></span>

  </a>
   <a href="exel/indexadmin.php"class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-file-excel-o"tabindex="0"aria-controls="example"type="button">
    <span></span>

  </a>
  
  </a>
   <a href="rechercheadmin.php"class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-search"tabindex="0"aria-controls="example"type="button">
    <span></span>


  </a>
    <!DOCTYPE html>
<html lang="en">
<script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.js"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <button id="demo" class="btn btn-outline-primary fa fa-photo" onclick="downloadtable()"></button>


    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
</body>

<script>

    function downloadtable() {

        var node = document.getElementById('tablecontainer');

        domtoimage.toPng(node)
            .then(function (dataUrl) {
                var img = new Image();
                img.src = dataUrl;
                downloadURI(dataUrl, "records.png")
            })
            .catch(function (error) {
                console.error('oops, something went wrong!', error);
            });

    }



    function downloadURI(uri, name) {
        var link = document.createElement("a");
        link.download = name;
        link.href = uri;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        delete link;
    }



</script>

</html>
  

                              <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-print"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span></span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>

   
        </div>
    </div>
    <div id="tablecontainer">
       
              <table  id="example"  class="table table-bordered">
                <thead>
                    <tr>
         <th> <a class="column_sort" id="id" data-order="desc" href="#">ID</a></th>
            <th><a class="column_sort" id="usertype" data-order="desc" href="#">USERTYPE</a>  </th>
            <th><a class="column_sort" id="username" data-order="desc" href="#">USERNAME</a> </th>
            <th><a class="column_sort" id="email" data-order="desc" href="#">EMAIL</a></th>
            <th><a class="column_sort" id="password" data-order="desc" href="#">PASSWORD</a></th>
            <th><a class="column_sort" id="IMAGE" data-order="desc" href="#">IMAGE</a></th>

            <td align="center" colspan="2">Actions</td>
                    </tr> 
                     </thead>
                <tbody>
  
     <?php
       $page1=0;
     if (isset($_GET['page'])){
     $page=$_GET["page"];
if($page=="" || $page=="1")
{
  $page1=0;
}
else
{
  $page1=($page*5)-5;
}
}
$res=mysqli_query($mysqli,"SELECT * FROM register order by id DESC limit $page1,5 ");
while($row=mysqli_fetch_array($res))
{

 
  
    ?>
<tr>
  <td><?php echo $row['id']; ?> </td>
      <td><?php echo $row['usertype']; ?> </td>
      <td><?php echo $row['username']; ?> </td>
      <td><?php echo $row['email']; ?> </td>
      <td><?php echo $row['password']; ?> </td>
      <td><?php echo $row['image']; ?> </td>

      <td>
       
    <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

     <a href="editadmin.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary fa fa-edit">
    </a>
      </td>
      
<td>
  <input type="hidden" class="delete_id_value"value="<?php echo $row['id']; ?>">
         <a href="javascript:void(0)" class="delete_btn_ajax btn btn-primary fa fa-trash"></a>

      </td>
    </tr>
    <?php
  
}

$res1=mysqli_query($mysqli,"SELECT * FROM register");
  $cou=mysqli_num_rows($res1);
  $a=$cou/5;
  $a=ceil($a);
  echo"<br>"; echo"<br>";
  for($b=1;$b<=$a;$b++)
  {
    ?><a  href="afficheradmin.php?page=<?php echo $b ?>"class='btn btn-primary'style="text -decoration:none"><?php echo $b." "; ?></a><?php
  }
 


     ?>
     


                 
                </tbody>
                <tfoot>   

                   
            </table>
                        </div>

            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->

<!--start overlay-->
      <div class="overlay toggle-menu"></div>
    <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  
  <!--End footer-->
  
  <!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
  
  
   <p class="mb-0">Header Colors</p>
      <hr>
    
    <div class="mb-3">
      <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
    </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
    
      <div class="mb-3">
      <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
    </div>
    
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->

<script>  
 $(document).ready(function(){  
      $(document).on('click', '.column_sort', function(){  
           var column_name = $(this).attr("id");  
           var order = $(this).data("order");  
           var arrow = '';  
           //glyphicon glyphicon-arrow-up  
           //glyphicon glyphicon-arrow-down  
           if(order == 'desc')  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';  
           }  
           else  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';  
           }  
           $.ajax({  
                url:"sortadmin.php",  
                method:"POST",  
                data:{column_name:column_name, order:order},  
                success:function(data)  
                {  
                     $('#employee_table').html(data);  
                     $('#'+column_name+'').append(arrow);  
                }  
           })  
      });  
 });  
 </script> 

  <?php
include('includes/scripts.php');
include('includes/footer.php');
?>