
<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/loginC.php";
$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">ADDING DELIVRIE Boys</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">ADDING DELIVRIE BOYS</li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
          <form action="ajoutadmin.php" method="GET" id ="myform">
                <h4 class="form-header text-uppercase">
                  <i class="fa fa-user-circle-o"></i>
            Gestion Admin
                </h4>
  <div class="form-group row">
                  <label for="input-3" class="col-sm-2 col-form-label">ID</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-3" name="id" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-1" class="col-sm-2 col-form-label">USERTYPE</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-1" name="usertype" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-3" class="col-sm-2 col-form-label">USERNAME</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-3" name="username" required>
                  </div>
                </div>
                <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">EMAIL</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="input-4" name="email" required>
                  </div>
                </div>
  <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">PASSWORD</label>
                  <div class="col-sm-10">
                    <input type="password" class="form-control" id="input-4" name="password" required>
                  </div>
                </div>
                 <div class="form-group row">
                  <label for="input-4" class="col-sm-2 col-form-label">IMAGE</label>
                  <div class="col-sm-10">
                    <input type="image" class="form-control" id="input-4" name="image" required>
                  </div>
                </div>

                <div class="form-footer">
                   <button type="submit" class="btn btn-danger"><i class="fa fa-times"></i> </button>
                    <button  type="submit" class="btn btn-success fa fa-user-plus" name="registerbtn2" onclick="anim5_noti()"></button>
                   
                </div>
              </form>
            </div>
          </div>
        </div>
      </div><!--End Row-->

    
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  

  
  <!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
  
  
   <p class="mb-0">Header Colors</p>
      <hr>
    
    <div class="mb-3">
      <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
    </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
    
      <div class="mb-3">
      <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
    </div>
    
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
   
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>

