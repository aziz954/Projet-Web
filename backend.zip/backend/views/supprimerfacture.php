<?PHP
include "../core/factureC.php";
$factureC=new factureC();
if (isset($_POST["id"])){
  $factureC->supprimerfacture($_POST["id"]);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A bill has been Deleted', 'unread', CURRENT_TIMESTAMP, 'afficherfacture.php');";
  $db = config::getConnexion();

  try{
  
          $req=$db->prepare($sql);

    $req->execute();
     
  }
    catch (Exception $e){
    echo 'Erreur: '.$e->getMessage();
  }
  header('Location: afficherfacture.php');
}

?>