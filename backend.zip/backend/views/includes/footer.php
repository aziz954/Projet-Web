<footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2019 Bulona Admin
        </div>
      </div>
    </footer>
     
  </div><!--End wrapper-->

    <script src="js/sweetalert.js"></script>

<script src="https://code.jquery.com/jquery-3.5.0.min.js" ></script>
    <script >

      $(document).ready(function(){
      $('.delete_btn_ajax').click(function(e){
e.preventDefault();
var deleteid=$(this).closest("tr").find('.delete_id_value').val();
//console.log(deleteid);
swal({
  title: "Are you sure?",
  text: "Once deleted, you will not be able to recover this data!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
 $.ajax({



  type:"POST",
  url:"code.php",
  data:{
   "delete_btn_set":1,
   "delete_id":deleteid, 
  },
  success:function(response)
  {
swal("Data deleted Successfully.!",{
icon:"success",
}).then ((result)=>{
      document.location = document.location.href + "?afterReload=true";

});
  }
 });


  } 
});

      });
    });
    </script>

  
</body>

<!-- Mirrored from codervent.com/bulona/demo/table-data-tables.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 11 Apr 2020 21:28:22 GMT -->
</html>
