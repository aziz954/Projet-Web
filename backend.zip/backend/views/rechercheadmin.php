<?php
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/photoCore.php";
include "../core/loginC.php";

$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
?>
<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="jquery-3.5.0.min.js"></script>
<script src="sweetalert2.all.min"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
<script language="javascript"type="text/javascript" src="verif_liv.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

 <script src="jquery-3.5.0.min.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  

<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Data Tables</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Tables</a></li>
            <li class="breadcrumb-item active" aria-current="page">Data Tables</li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
   

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Delevries Data </div>
            <div class="card-body">
              <div class="table-responsive"id="employee_table">
                  <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
      <div class="row">
        <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/admin.php"class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-file-pdf-o"tabindex="0"aria-controls="example"type="button">
    <span></span>

  </a>
   <a href="exel/indexadmin.php"class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-file-excel-o"tabindex="0"aria-controls="example"type="button">
    <span></span>

  </a>
  

                             <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5 fa fa-print"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span></span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>

   
        </div>
    </div>
        <div class="col-sm-12 col-md-6">
          <div id="example_filter"class="dataTables_filter">
            <label>
              Search:
              <input type="Search"name="search_text"id="search_text"class="form-control form-control-sm"placeholderaria-controls="example">
            </label>

      </div>
    </div>
              <div id="result"></div>

            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->

<!--start overlay-->
      <div class="overlay toggle-menu"></div>
    <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  
  <!--End footer-->
  
  <!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
  
  
   <p class="mb-0">Header Colors</p>
      <hr>
    
    <div class="mb-3">
      <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
    </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
    
      <div class="mb-3">
      <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
    </div>
    
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->
<script>
$(document).ready(function(){
  load_data();
  function load_data(query)
  {
    $.ajax({
      url:"fetchadmin.php",
      method:"post",
      data:{query:query},
      success:function(data)
      {
        $('#result').html(data);
      }
    });
  }
  
  $('#search_text').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
      load_data(search);
    }
    else
    {
      load_data();      
    }
  });
});
</script>
<script>  
 $(document).ready(function(){  
      $(document).on('click', '.column_sort', function(){  
           var column_name = $(this).attr("id");  
           var order = $(this).data("order");  
           var arrow = '';  
           //glyphicon glyphicon-arrow-up  
           //glyphicon glyphicon-arrow-down  
           if(order == 'desc')  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';  
           }  
           else  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';  
           }  
           $.ajax({  
                url:"sortadmin.php",  
                method:"POST",  
                data:{column_name:column_name, order:order},  
                success:function(data)  
                {  
                     $('#employee_table').html(data);  
                     $('#'+column_name+'').append(arrow);  
                }  
           })  
      });  
 });  
 </script> 

  <?php
include('includes/scripts.php');
include('includes/footer.php');
?>