<?PHP
include "../core/fournisseurC.php";
$fournisseurC=new fournisseurC();
if (isset($_POST["id"])){
  $fournisseurC->supprimerFournisseur($_POST["id"]);
  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'fournisseur supprimé', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: afficherfournisseur.php');
}

?>