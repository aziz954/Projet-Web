<?PHP
include "../core/livraisonC.php";
$livC=new livC();
if (isset($_POST["id"])){
  $livC->supprimerliv($_POST["id"]);
  	  $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'DELETE', 'A delevryhas been Deleted', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
  header('Location: afficherliv.php');
}

?>