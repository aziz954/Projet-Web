 <?php
session_start();
$connection = mysqli_connect("localhost","root","","medline");

if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirmpassword'];

    if($password === $confirm_password)
    {
        $query = "INSERT INTO register (username,email,password) VALUES ('$username','$email','$password')";
        $query_run = mysqli_query($connection, $query);
    
        if($query_run)
        {
            echo "done";
            $_SESSION['success'] =  "Admin is Added Successfully";
            header('Location: register.php');
        }
        else 
        {
            echo "not done";
            $_SESSION['status'] =  "Admin is Not Added";
            header('Location: register.php');
        }
    }
    else 
    {
        echo "pass no match";
        $_SESSION['status'] =  "Password and Confirm Password Does not Match";
        header('Location: register.php');
    }

}



if (isset($_POST['updatebtn']))
{

    $id=$_POST['edit_id'];
    $username=$_POST['edit_username'];
    $email=$_POST['edit_email'];
    $password=$_POST['edit_password'];
    $query="UPDATE register SET username='$username',email='$email', password='$password'WHERE id='$id' ";
    $query_run=mysqli_query($connection, $query);
    if($query_run)
    {
        $_SESSION['success']="Your Data is Updated";
        header('Location: register.php');

    }
    else
    {
        $_SESSION['status']="Your Data is Not Updated";
        header('Location: register.php');
    }
}

if (isset($_POST['delete3']))
{

    $query="DELETE FROM `notifications` ";
    $query_run=mysqli_query($connection,$query);
    if($query_run)
    {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
 }  
 else
 {
     header('Location: ' . $_SERVER['HTTP_REFERER']);
 }
}

if (isset($_POST['login_btn']))
{
    $email_login=$_POST['emaill'];
    $password_login=$_POST['passwordd'];
    $query ="SELECT * FROM register WHERE email='$email_login' AND password='$password_login'";
    $query_run=mysqli_query($connection ,$query);
    if ($query_run)
    {
        $_SESSION['username']=$email_login;
        header('Location: index.php ');
    }
    else
    {
        $_SESSION['status']='Email id / Password is Invalid';
        header('Location : login.php');
    }
}

if(isset($_POST['registerbtn2']))
{
    $id = $_POST['id'];
    $ref = $_POST['ref'];
    $adr = $_POST['adr'];
    $heure = $_POST['heure'];
    $datee= $_POST['datee'];

    
        $query = "INSERT INTO livraison (id,ref,adr,heure,datee) VALUES ('$id','$ref','$adr','$heure','$datee')";
        $query_run = mysqli_query($connection, $query);
    
        if($query_run)
        {
            echo "done";
            $_SESSION['success'] =  "Delivery is Added Successfully";
            header('Location: gestionliv.php');
        }
        else 
        {
            echo "not done";
            $_SESSION['status'] =  "Delivery is Not Added";
            header('Location: gestionliv.php');
        }
    }
    
    if(isset($_POST['registerbtn3']))
{
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];
    $num = $_POST['num'];
    $id = $_POST['id'];
        $query = "INSERT INTO client (nom,prenom,adresse,num,id) VALUES ('$nom','$prenom','$adresse','$num','$id')";
        $query_run = mysqli_query($connection, $query);
        if($query_run)
        {
            echo "done";

            $_SESSION['success'] =  "Client is Added Successfully";

            header('Location: gestionclient.php');
        }
        else 
        {
            echo "not done";
            $_SESSION['status'] =  "Client is Not Added";
            header('Location: gestionclient.php');
        }

}
if (isset($_POST['updatebtn2']))
{

    $id=$_POST['edit_id'];
    $ref=$_POST['edit_ref'];
    $adr=$_POST['edit_adr'];
    $heure=$_POST['edit_heure'];
    $datee=$_POST['edit_datee'];
    $query="UPDATE livraison SET id='$id',ref='$ref',adr='$adr',heure='$heure',datee='$datee'WHERE id='$id' ";
    $query_run=mysqli_query($connection, $query);
    if($query_run)
    {
        $_SESSION['success']="Your Data is Updated";
        header('Location: gestionliv.php');

    }
    else
    {
        $_SESSION['status']="Your Data is Not Updated";
        header('Location: gestionliv.php');
    }
}

if (isset($_POST['updatebtn3']))
{
    $nom=$_POST['edit_nom'];
    $prenom=$_POST['edit_prenom'];
    $adresse=$_POST['edit_adresse'];
    $num=$_POST['edit_num'];
    $id=$_POST['edit_id'];
    $query="UPDATE client SET nom='$nom',prenom='$prenom', adresse='$adresse ', num = '$num', id = '$id' WHERE id='$id' ";
    $query_run=mysqli_query($connection, $query);
    if($query_run)
    {
        $_SESSION['success']="Your client informations are Updated";
        header('Location: gestionclient.php');
    }
    else
    {
        $_SESSION['status']="Your client informations are Not Updated";

        header('Location: gestionclient.php');
    }
}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM livraison WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}

if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM vendeurs WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM product WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM register WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM facture WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM commande WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM fourniture WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM medicament WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM fournisseur WHERE id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
if (isset($_POST['delete_btn_set']))
{

    $del_id=$_POST['delete_id'];
    $query="DELETE  FROM rating WHERE rating_id='$del_id'";
    $query_run=mysqli_query($connection,$query);
   

}
?>