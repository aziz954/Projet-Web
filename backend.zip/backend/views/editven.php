
<?php
//include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/vendeur.php";
include "../core/vendeurC.php";
if (isset($_GET['id'])){
    $venC=new venC();
    $result=$venC->recupererven($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $nom=$row['nom'];
        $prenom=$row['prenom'];
        $num=$row['num'];
        
       
        ?>

<!--End topbar header-->
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">
    <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Editing Sellers Form</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Bulona</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Forms</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editing Sellers </li>
         </ol>
     </div>
     <div class="col-sm-3">
       <div class="btn-group float-sm-right">
        <button type="button" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i> Setting</button>
        <button type="button" class="btn btn-light dropdown-toggle dropdown-toggle-split waves-effect waves-light" data-toggle="dropdown">
        <span class="caret"></span>
        </button>
        <div class="dropdown-menu">
          <a href="javaScript:void();" class="dropdown-item">Action</a>
          <a href="javaScript:void();" class="dropdown-item">Another action</a>
          <a href="javaScript:void();" class="dropdown-item">Something else here</a>
          <div class="dropdown-divider"></div>
          <a href="javaScript:void();" class="dropdown-item">Separated link</a>
        </div>
      </div>
     </div>
     </div>
    <!-- End Breadcrumb-->


  

      <div class="row">
      <div class="col-lg-12">
         
       
       <div class="card">
        <form method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
           <div class="card-body">
           <div class="card-title">Editing Sellers </div>
           <hr>
            <form>
           <div class="form-group row">
            <label for="input-26" class="col-sm-2 col-form-label">ID :</label>
            <div class="col-sm-10">
            <input type="text" class="form-control form-control-rounded" id="id"name="id" value="<?php echo $row['id']; ?>" placeholder="Enter Your id"readonly>
            </div>
          </div>
 
          <div class="form-group row">
            <label for="input-27" class="col-sm-2 col-form-label">Nom :</label>
            <div class="col-sm-10">
            <input type="text" class="form-control form-control-rounded" id="nom" name="nom" value="<?php echo $row['nom']; ?>"placeholder="Enter Your  First Name">
            </div>
          </div>
          <div class="form-group row">
            <label for="input-28" class="col-sm-2 col-form-label">Prenom :</label>
            <div class="col-sm-10">
            <input type="tetx" class="form-control form-control-rounded" name="prenom" value="<?php echo $row['prenom']; ?>"id="input-28" placeholder="Enter Your Last Name">
            </div>
          </div>
          <div class="form-group row">
            <label for="input-29" class="col-sm-2 col-form-label">Num:</label>
            <div class="col-sm-10">
            <input type="Number" class="form-control form-control-rounded"name="num" value="<?php echo $row['num']; ?>" id="datee" placeholder="Enter Number">
            </div>
          </div>
         
       
         
                <div class="form-footer">
                      <a href="afficherven.php" class="btn btn-danger fa fa-mail-reply"></a>
                    <button  type="submit" class="btn btn-success fa fa-edit" name="updatebtn2" onclick="anim5_noti()"></button>
                   
                </div>
          </form>
         </div>
         </div>

      </div>
            <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])and !empty($_POST['nom'])and !empty($_POST['prenom'])and !empty($_POST['num'])){
    
    $ven=new ven($_POST['id'],$_POST['nom'],$_POST['prenom'],$_POST['num']);
    $venC->modifierven($ven,$_POST['edit_id']);

     $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'A seller has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionvend.php');";
        $db = config::getConnexion();

        try{
      
                        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
    echo '<meta http-equiv="refresh" content="0; URL=afficherven.php">';
}
?>
      </div><!--End Row-->
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
   </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  <footer class="footer">
      <div class="container">
        <div class="text-center">
          Copyright © 2019 Bulona Admin
        </div>
      </div>
    </footer>
  <!--End footer-->
  
  <!--start color switcher-->
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
  
  
   <p class="mb-0">Header Colors</p>
      <hr>
    
    <div class="mb-3">
      <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
    </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
    
      <div class="mb-3">
      <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
    </div>
    
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
  <!--end color switcher-->

<?php
include('includes/scripts.php'); 
include('includes/footer.php'); 


        ?>