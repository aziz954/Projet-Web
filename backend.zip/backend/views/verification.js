function verifier() {
    var errors ="";
    if(document.myform.id.value==""){
        <div class='alert alert-danger'>Insert id</div>
        errors += "a"; 
    }

    if(document.myform.q.value==""){
        <div class='alert alert-danger'>Insert quantity</div>
        errors += "b";
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 ){
        <div class='alert alert-danger'>Insert id de longueur 8</div>
        errors += "c";
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    else {
        <div class='alert alert-success'>Success</div>
    }
    
    }

