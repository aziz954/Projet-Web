<?php  
 //sort.php  
include "../core/livraisonC.php";
$liv1C=new livC();
$listeliv=$liv1C->afficherliv();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id as ref FROM vendeurs");
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM livraison ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
  <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/livpdf.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>PDF</span>

  </a>
   <a href="exel/index.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>EXEL</span>

  </a>
  

                                   <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span>PRINT</span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  
   
        </div>


      </div>
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
           <th><a class="column_sort" id="ref" data-order="'.$order.'" href="#">Reference</a></th>  
           <th><a class="column_sort" id="adr" data-order="'.$order.'" href="#">Adresse</a></th>  
           <th><a class="column_sort" id="heure" data-order="'.$order.'" href="#">Time</a></th>  
           <th><a class="column_sort" id="datee" data-order="'.$order.'" href="#">Date</a></th> 
           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["ref"] . '</td>  
           <td>' . $row["adr"] . '</td>  
           <td>' . $row["heure"] . '</td>  
           <td>' . $row["datee"] . '</td> 
              <td align="center">
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="editliv.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
  <i class="fas fa-edit"></i></a>
      </td>
  <td align="center">

        <form action ="supprimerliv.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-tresh-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>   