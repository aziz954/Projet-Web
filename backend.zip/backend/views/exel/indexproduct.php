<?php 
include_once("inc/db_connect.php");
include("exportproduct.php");
include("inc/header.php"); 
?>
<title>Exporting Data to Excel using PHP & MySQL</title>
<?php include('inc/container.php');?>
<div class="container">	
	<h2><center> Exporting Data to Excel</center></h2>
	<div class="well-sm col-sm-12">
		<div class="btn-group pull-right">	
			<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">					
				<button type="submit" id="dataExport" name="dataExport" value="Export to excel" class="btn btn-info">Export To Excel</button>
			</form>
		</div>
	</div>				  
	<table id="" class="table table-striped table-bordered">
		<tr>
			<th> ID</th>
            <th>Produit name</th>
            <th>Image</th>
            <th>pprice</th>
            <th>Quantity</th>
            <th>description</th>
            <th>pmaterial</th>
            <th>pbrand</th>
            <th>pcolor</th>
            <th>IDC</th>
            <th>price</th>
            <th>material</th>
            <th>color</th>
            <th>brand</th>
            <th>type</th>		
			
		</tr>
		<tbody>
			<?php foreach($developersData as $developer) { ?>
			   <tr>
			   <td><?php echo $developer ['id']; ?></td>
			   <td><?php echo $developer ['pname']; ?></td>
			   <td><?php echo $developer ['image']; ?></td>  
				<td><?php echo $developer ['pprice']; ?></td>
								<td><?php echo $developer ['Quantity']; ?></td>			   
				<td><?php echo $developer ['description']; ?></td>			   
				<td><?php echo $developer ['pmaterial']; ?></td>			   
				<td><?php echo $developer ['pbrand']; ?></td>			   
				<td><?php echo $developer ['pcolor']; ?></td>			   
				<td><?php echo $developer ['IDC']; ?></td>			   
				<td><?php echo $developer ['price']; ?></td>			   
				<td><?php echo $developer ['material']; ?></td>	
				<td><?php echo $developer ['color']; ?></td>			   
				<td><?php echo $developer ['brand']; ?></td>			   
				<td><?php echo $developer ['type']; ?></td>			   

			   
			   </tr>
			<?php } ?>
		</tbody>
    </table>		
</div>
<?php include('inc/footer.php');?>




