<?PHP
include "../entities/medicament.php";
include "../core/medicamentC.php";

if (!empty($_GET['id'])  and !empty($_GET['nom']) and !empty($_GET['quantite']) and !empty($_GET['fournisseur'])){
  $medicament1=new medicament($_GET['id'],$_GET['nom'],$_GET['quantite'],$_GET['fournisseur'],$_GET['prix']);

$medicament1C=new medicamentC();
$medicament1C->ajouter($medicament1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
        header('Location:affichermedicament.php?message=<div class="alert alert-success">success</div>');	
}
else{
  if (empty($_GET['id'])){
    header('Location:affichermedicament.php?message=<div class="alert alert-danger">id missing</div>');
  } 
  if (empty($_GET['nom'])){
    header('Location:affichermedicament.php?message=<div class="alert alert-danger">name missing</div>');
  } 
  if (empty($_GET['quantite'])){
    header('Location:affichermedicament.php?message=<div class="alert alert-danger">quantity missing</div>');
  }
}
//*/

?>