<?php
$dbhost='localhost';
$dbname='medline';
$dbuser='root';
$dbpass='';

try{


	$dbcon=new PDO("mysql:host={$dbhost};dbname={$dbname}",$dbuser,$dbpass);
	$dbcon ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

	print "Error!:". $e->getMessage() ."<br/>";
	die();

}

$stmt = $dbcon->prepare("SELECT type,id_client FROM avis ");
$stmt->execute();
$row1=[];
while($row=$stmt->fetch(PDO::FETCH_ASSOC))
{
	extract($row);
	$row1[]=['type' => $type, 'id_client' => $id_client];
}
echo json_encode($row1);






?>