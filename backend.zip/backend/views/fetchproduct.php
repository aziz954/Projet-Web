<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM product 
	WHERE id LIKE '%".$search."%'
	OR pname LIKE '%".$search."%' 
	OR image LIKE '%".$search."%' 
	OR pprice LIKE '%".$search."%' 
	OR Quantity LIKE '%".$search."%'
    OR description LIKE '%".$search."%'
  OR pmaterial LIKE '%".$search."%'
  OR pbrand LIKE '%".$search."%'
  OR pcolor LIKE '%".$search."%'
  OR IDC LIKE '%".$search."%'
  OR price LIKE '%".$search."%'
  OR material LIKE '%".$search."%'
  OR color LIKE '%".$search."%'
  OR brand LIKE '%".$search."%'
  OR type LIKE '%".$search."%'


	";
}
else
{
	$query = "
	SELECT * FROM product ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '  
   
 <table class="table table-bordered">  
      <tr>
         <th> ID</th>
            <th>Produit name</th>
            <th>Image</th>
            <th>pprice</th>
            <th>Quantity</th>
            <th>description</th>
            <th>pmaterial</th>
            <th>pbrand</th>
            <th>pcolor</th>
            <th>IDC</th>
            <th>price</th>
            <th>material</th>
            <th>color</th>
            <th>brand</th>
            <th>type</th>
            <td align="center" colspan="2">Actions</td>
                    </tr> 

 ';  

	while($row = mysqli_fetch_array($result))
	{
	 $output .= '  
       <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["pname"] . '</td>  
           <td>' . $row["image"] . '</td>  
           <td>' . $row["pprice"] . '</td>  
          <td>' . $row["Quantity"] . '</td>  
           <td>' . $row["description"] . '</td> 
          <td>' . $row["description"] . '</td>  
                     <td>' . $row["pmaterial"] . '</td>  
           <td>' . $row["pbrand"] . '</td>  
           <td>' . $row["pcolor"] . '</td>  
           <td>' . $row["IDC"] . '</td>  
           <td>' . $row["price"] . '</td>  
           <td>' . $row["material"] . '</td>  
           <td>' . $row["color"] . '</td> 
            <td>' . $row["brand"] . '</td>  
           <td>' . $row["type"] . '</td>  

             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierproduct.php?id= ' . $row["id"] . ' " class ="btn btn-primary fa fa-edit">
    </a>
      </td>
  <td>

        <form action ="supprimerproduct.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2"  class="delete_btn_ajax btn btn-primary fa fa-trash"></i></button>
      </form>
      </td>
      </tr>  
      ';  
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>