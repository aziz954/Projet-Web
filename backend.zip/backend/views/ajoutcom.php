<?PHP
include "../entities/commande.php";
include "../core/commandeC.php";

if (!empty($_GET['id']) and !empty($_GET['id_cl']) and !empty($_GET['q']) ){
$commande1=new commande($_GET['id'],$_GET['id_cl'],$_GET['q']);

$commande1C=new commandeC();
$commande1C->ajoutercommande($commande1);

$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A commmand has been Added', 'unread', CURRENT_TIMESTAMP, 'affichercom.php');";
		$db = config::getConnexion();
		try{
      
				        $req=$db->prepare($sql);
            $req->execute();
           
        }
          catch (Exception $e){
           
            echo 'Erreur: '.$e->getMessage();
        }
header('Location:affichercom.php?message=<div class="alert alert-success">success</div>');
	
}else{
  if (empty($_GET['id'])){
    header('Location:affichercom.php?message=<div class="alert alert-danger">id missing</div>');
  } 
	if (empty($_GET['q'])){
    header('Location:affichercom.php?message=<div class="alert alert-danger">quantity missing</div>');
  }
}
//*/

?>