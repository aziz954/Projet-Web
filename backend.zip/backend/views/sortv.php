<?php  
 //sort.php  
include "../core/vendeurC.php";
$ven1C=new venC();
$listeven=$ven1C->afficherven();
$mysqli=NEW MySQLi('localhost','root','','medline');
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM vendeurs ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
        <div class="col-sm-12 col-md-6">
<div class="dt-buttons btn-group">
  <a href="fpdf/livpdf.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>PDF</span>

  </a>
   <a href="exel/index.php"class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"type="button">
    <span>EXEL</span>

  </a>
  

                                   <button type="submit" class="btn btn-outline-primary buttons-pdf buttons-html5"tabindex="0"aria-controls="example"  onsubmit="myfun()"> 
                            <span>PRINT</span>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  
   
        </div>


      </div>
 <table class="table table-bordered">  

      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
           <th><a class="column_sort" id="nom" data-order="'.$order.'" href="#">Reference</a></th>  
           <th><a class="column_sort" id="prenom" data-order="'.$order.'" href="#">Adresse</a></th>  
           <th><a class="column_sort" id="num" data-order="'.$order.'" href="#">Time</a></th>  
           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["nom"] . '</td>  
           <td>' . $row["prenom"] . '</td>  
           <td>' . $row["num"] . '</td>  

             <td>
       
              <input type="hidden" name ="edit_id2" value=' . $row["id"] . '>

     <a href="editliv.php?id= ' . $row["id"] . '" class ="btn btn-primary ">
  EDIT</a>
      </td>
      <td>
       <input type="hidden" class="delete_id_value"value="<?php echo $row['id']; ?>">
         <a href="javascript:void(0)" class="delete_btn_ajax btn btn-danger"> <i class="fas fa-trash-alt"></i></a>
   
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  