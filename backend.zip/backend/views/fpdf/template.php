<?php
 $connect = mysqli_connect("localhost", "root", "", "medline");  
?>

<!DOCTYPE html>
<!--
  Invoice template by invoicebus.com
  To customize this template consider following this guide https://invoicebus.com/how-to-create-invoice-template/
  This template is under Invoicebus Template License, see https://invoicebus.com/templates/license/
-->
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Easy (corporate)</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Invoicebus Invoice Template">
    <meta name="author" content="Invoicebus">

    <meta name="template-hash" content="91216e926eab41d8aa403bf4b00f4e19">

    <link rel="stylesheet" href="css/template.css">
  </head>
  <body>
    <div id="container">
      <div class="left-stripes">
        <div class="circle c-upper"></div>
        <div class="circle c-lower"></div>
      </div>

      <div class="right-invoice">
        <section id="memo">
          <div class="company-info">
            <div>Medline</div>
            <br>
            <span>Rue de france</span>
            <span>Tunis 2080</span>
            <br>
            <span>+216 71715558</span>
            <br>
            <span>coccicocci03@gmail.com</span>
          </div>

          <div class="logo">
            <img src="a.png" />
          </div>
        </section>

        <section id="invoice-title-number">

          <div class="title-top">
            <span class="x-hidden">{issue_date_label}</span>
            <span>{issue_date}</span> <span id="number">{invoice_number}</span>
          </div>
        
          <div id="title">Facture</div>
          
        </section>

        <section id="client-info">
          <span>{bill_to_label}</span>
          <div class="client-name">
            <span>Aziz Allouche</span>
          </div>
          
          <div>
            <span>Rue Ibn Mandhour</span>
          </div>
          
          <div>
            <span>Ariana 2080</span>
          </div>
          
          <div>
            <span>+216 95118898</span>
          </div>
          
          <div>
            <span>azizaziz97450@gmail.com</span>
          </div>
   
        </section>

        
        
        <div class="clearfix"></div>
        
        <section id="invoice-info">
          <div>
            <span>{net_term_label}</span> <span>{net_term}</span>
          </div>
          <div>
            <span>{due_date_label}</span> <span>{due_date}</span>
          </div>
          <div>
            <span>{po_number_label}</span> <span>{po_number}</span>
          </div>
        </section>
        
        <div class="clearfix"></div>

        <div class="currency">
          <span>{currency_label}</span> <span>{currency}</span>
        </div>
        
        <section id="items">
		
				<table border="1" cellpadding="0" cellspacing="0">
					<tbody class="head">
                        <tr>
              
              <th>       </th>
              <th class="pname">{item_description_label}</th>
              <th  class="price">{item_quantity_label}</th>
              <th class="Quantity">{item_price_label}</th>
              
    
            </tr>
					</tbody>

					<tbody class="body">

						<?php
			$query2 = "SELECT * FROM cart";     
                $result2 = mysqli_query($connect, $query2);  
                if(mysqli_num_rows($result2) > 0)  
                {  
                     while($row = mysqli_fetch_array($result2))  
                     {  
?>
						<tr>
              <td>      </td>
              <td class="pname"><?php echo $row["pname"]; ?></td>
							<td class="price"><?php echo $row["price"]; ?></td>
              <td class="Quantity"><?php echo $row["Quantity"]; ?></td>
                            
                            
						</tr>
				<?php

			}
		}
		?>
					</tbody>
                </table>
                

	</section> 

    <section id="sums">
        
        <table cellpadding="0" cellspacing="0">
          
          
          <tr class="amount-total">
          
<?php

            $query5 = "SELECT (SUM(price*Quantity)) AS prix_total FROM cart";
            $result5 = mysqli_query($connect, $query5);        
            if(mysqli_num_rows($result2) > 0)  
            {  
                 while($row = mysqli_fetch_array($result5))  
                 {  
         
                   ?>  
                       <td colspan="2"><?php echo $row['prix_total']; ?> TND</td>
                    
             <?php  
                        }  
                   } 
                   
                   ?>



          </tr>
          

          
        </table>
        
      </section>

      <div class="clearfix"></div>
        
        <section id="terms">
        
          <span> TERMS</span>
          <div>Thank you very much. We really appreciate your business.
Please send payments before the due date.</div>
          
        </section>
        <div class="payment-info">
          <div>{payment_info1}</div>
          <div>{payment_info2}</div>
          <div>{payment_info3}</div>
          <div>{payment_info4}</div>
          <div>{payment_info5}</div>
        </div>
  </body>
</html>
