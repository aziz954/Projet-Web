<?php

session_start();
header('location:login.php');
$con=mysqli_connect('localhost' ,'root','');

mysqli_select_db($con,'userregistration');

$name = isset($_POST['user']) ? $_POST['user'] : NULL;
$pass = isset($_POST['password']) ? $_POST['password'] : NULL;
$s= "select * from usertable where name='$name'";

$result = mysqli_query ($con,$s);

$num = mysqli_num_rows($result);

if ($num == 1) 
{
	echo "Usename Already Taken";
}
else 
{
	$reg="INSERT INTO usertable (name,password) VALUES ('$name','$pass')";
	mysqli_query($con,$reg);
	echo "Registration Successful";
}
?>