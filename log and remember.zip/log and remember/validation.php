<?php

session_start();

$con=mysqli_connect('localhost' ,'root','');

mysqli_select_db($con,'userregistration');
if (isset($_POST['submit'])) 
{
$name = isset($_POST['name']) ? $_POST['name'] : NULL;
$pass = isset($_POST['password']) ? $_POST['password'] : NULL;
$rem = isset($_POST['remember']) ? $_POST['remember'] : NULL;
 
 

$s= "select * from usertable where name='$name'";

$result = mysqli_query ($con,$s);

$num = mysqli_num_rows($result);

if ($num > 0) 
{
	if (isset($_POST['remember']) == '$rem') 
	{
		setcookie('name',$name, time()+60*60*7);
		setcookie('password',$pass, time()+60*60*7);

	}
	$row = mysqli_fetch_array($result);
	$password_hash = $row['password'];
	if (password_verify($pass, $password_hash)) 
	{
		$_SESSION['name']=$name;

		header('location:home.php');	
	}
	
	
}
else 
{
	header('location:index.php');
}
}
?>