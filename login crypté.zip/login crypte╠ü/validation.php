<?php

session_start();

$con=mysqli_connect('localhost' ,'root','');

mysqli_select_db($con,'userregistration');
if (isset($_POST['user'])=="POST") 
{
$name = isset($_POST['user']) ? $_POST['user'] : NULL;
$pass = isset($_POST['password']) ? $_POST['password'] : NULL;
 
 

$s= "select * from usertable where name='$name'";

$result = mysqli_query ($con,$s);

$num = mysqli_num_rows($result);

if ($num > 0) 
{
	$row = mysqli_fetch_array($result);
	$password_hash = $row['password'];
	if (password_verify($pass, $password_hash)) 
	{
		header('location:home.php');	
	}
	
	
}
else 
{
	header('location:login.php');
}
}
?>