<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/medicamentC.php";
$medicament1C=new medicamentC();
$listemedicament=$medicament1C->affichermedicament();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT fournisseur as fournisseur FROM fournisseur");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="jquery-3.5.0.min.js"></script>
<script src="sweetalert2.all.min"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form name="myform" action="ajoutmedicament.php" method="GET">

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                  <input type="text" minlength="8" maxlength="8" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
            <label> Name </label>
                  <input type="text"  name="nom" class="form-control" placeholder="Enter Name">
            </div>
            <div class="form-group">
            <label> Quantity </label>
                  <input type="text"  name="quantite" class="form-control" placeholder="Enter Quantity">
            </div>
            <div class="form-group">
                <label>fournisseur</label>
                <select name="fournisseur"id="fournisseur">
                
<?php
while($rows = $result->fetch_assoc())
{
$fournisseur=$rows['fournisseur'];
echo"<option value='$fournisseur'>$fournisseur</option>";
}
?>
                </select>
            </div>
            
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">
  <form method="POST"action="">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small"  name="search_text" id="search_text"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary"><a href="gestionmedicament.php">Delivry Profile </a>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              Add Delivery Profile 
            </button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">Print</button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

 
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

      <div id="result"></div>

  </div>
</div>

</div>
<!-- /.container-fluid -->
<script>
$(document).ready(function(){
  load_data();
  function load_data(query)
  {
    $.ajax({
      url:"fetchm.php",
      method:"post",
      data:{query:query},
      success:function(data)
      {
        $('#result').html(data);
      }
    });
  }
  
  $('#search_text').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
      load_data(search);
    }
    else
    {
      load_data();      
    }
  });
});
</script>



<?php
include('includes/scripts.php');
include('includes/footer.php');
?>