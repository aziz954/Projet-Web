<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/productoC.php";
$product1C=new productC();
$listeproduct=$product1C->afficherproduct();
?>


<script type="text/javascript" src="verif.js"></script>

<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Delivery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="ajoutproduct.php" method="GET">

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="number" name="id" class="form-control" placeholder="Enter Id">
            </div>
            
            <div class="form-group">
                <label>Name</label>
                <input type="text" name="nom" class="form-control" placeholder="Enter Name">
            </div>
            <div class="form-group">
                <label>Quantite</label>
                <input type="number" name="quantite" class="form-control" placeholder="Enter Quantity">
            </div>

            <div class="form-group">
                <label>Image</label>
                <input type="text" name="image" class="form-control" placeholder="Enter Image">
            </div>

            <div class="form-group">
                <label>Price</label>
                <input type="flaot" name="prix" class="form-control" placeholder="Enter Price">
            </div>
            <div class="form-group">
                <label>Description</label>
                <input type="text" name="description" class="form-control" placeholder="Enter Image">
            </div>
               
        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <html>
            <body>
            <button type="submit" name="registerbtn2"  class="btn btn-primary" onClick="verifier()">Save</button>
            </body>
         
          </html>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">



<form method="POST">

   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Product Profile
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
              <i class="fas fa-plus-square"></i>
            </button>
                 
                                   <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()">
                                    <i class="fas fa-print"></i>
                                    </button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                  <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

 
    </h6>
  </div>
</form>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID </th>
           
            <th>Name </th>
            <th>Quantity</th>
            <th>image</th>
            <th>Price</th>
            <th>Description</th>
            <td align="center" colspan="2">Actions</td>


          </tr>
        </thead>
        <tbody>
        <?php

if (isset($_POST['search']))
{

  $recherche =$_POST['search'];

  $query = "SELECT * FROM producto WHERE CONCAT(`id`, `nom`, `quantite`, `image`, `prix`, `description`) LIKE '%".$recherche."%'";
  $search_result = filterTable($query);
 
}
else {
$query = "SELECT * FROM producto";
$search_result = filterTable($query);
}
function filterTable($query)
{
$connect = mysqli_connect("localhost", "root", "", "medline");
  $filter_Result = mysqli_query($connect, $query);
  return $filter_Result;

}  


?>
<?php while ($row = mysqli_fetch_array($search_result)):?>
 
<tr>
<td><?php echo $row['id']; ?> </td>
    <td><?php echo $row['nom']; ?> </td>
    <td><?php echo $row['quantite']; ?> </td>
    <td><?php echo $row['image']; ?> </td>
    <td><?php echo $row['prix']; ?> </td>
    <td><?php echo $row['description']; ?> </td>


    <td align="center">

  <input type="hidden" name ="edit_id2" value="<?php echo $row['id']; ?>">

   <a href="modifierproduct.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary ">
   <i class="fas fa-edit"></i></a>
    </td>
    <td align="center">
      <form action ="supprimerproduct.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

      <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash"></i></button>
    </form>
    </td>
  </tr>
    <?php endwhile;?>

         <?php

if (isset($_POST['search']))
{

  $recherche =$_POST['search'];

  $query = "SELECT * FROM producto WHERE CONCAT(`id`, `nom`, `quantite`, `image, `prix`, `description`) LIKE '%".$recherche."%'";
  $search_result = filterTable($query);
 
}
else {
$query = "SELECT * FROM producto";
$search_result = filterTable($query);
}



?>


 
  
      
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>