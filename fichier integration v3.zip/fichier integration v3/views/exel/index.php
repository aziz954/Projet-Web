<?php 
include_once("inc/db_connect.php");
include("export.php");
include("inc/header.php"); 
?>
<title>Exporting Data to Excel</title>
<?php include('inc/container.php');?>
<div class="container">	
	<h2><center> Exporting Data of Delevery Boys to Excel</center></h2>
	<div class="well-sm col-sm-12">
		<div class="btn-group pull-right">	
			<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">					
				<button type="submit" id="dataExport" name="dataExport" value="Export to excel" class="btn btn-info">Export To Excel</button>
			</form>
		</div>
	</div>				  
	<table id="" class="table table-striped table-bordered">
		<tr>
			<th>Nom</th>
			<th>Prenom</th>
			<th>ID</th>
			<th>IDLIV</th>			
			
		</tr>
		<tbody>
			<?php foreach($developersData as $developer) { ?>
			   <tr>
			   <td><?php echo $developer ['nom']; ?></td>
			   <td><?php echo $developer ['prenom']; ?></td>
			   <td><?php echo $developer ['id']; ?></td>  
				<td><?php echo $developer ['idliv']; ?></td>			   
			   </tr>
			<?php } ?>
		</tbody>
    </table>		
</div>
<?php include('inc/footer.php');?>




