<?php  
 //sortf.php  
include "../core/factureC.php";
$factureC1C=new factureC();
$listefactureC=$factureC1C->afficherfacture();
$mysqli=NEW MySQLi('localhost','root','','medline');
$connect = mysqli_connect("localhost","root","", "medline"); 
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM facture ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
           <th><a class="column_sort" id="mont" data-order="'.$order.'" href="#">Montant</a></th>  
           <th><a class="column_sort" id="id_com" data-order="'.$order.'" href="#">Id du client</a></th>  
           <th><a class="column_sort" id="id_cl" data-order="'.$order.'" href="#">Id du facture</a></th>  
           <th><a class="column_sort" id="datef" data-order="'.$order.'" href="#">Date</a></th>  

           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["mont"] . '</td>  
           <td>' . $row["id_com"] . '</td>  
           <td>' . $row["id_cl"] . '</td>  
           <td>' . $row["datef"] . '</td>  

             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierfacture.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
     <i class="fas fa-edit"></i> </a>
      </td>
  <td>

        <form action ="supprimerfacture.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"> </i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  