<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
     $search = mysqli_real_escape_string($connect, $_POST["query"]);
     $query = "
     SELECT * FROM fourniture 
     WHERE id LIKE '%".$search."%'
     OR nom LIKE '%".$search."%' 
     OR quantite LIKE '%".$search."%' 
     OR fournisseur LIKE '%".$search."%' 

     ";
}
else
{
     $query = "SELECT * FROM fourniture ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
     $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th>ID</th>  
           <th>Name client</th>  
           <th>Quantity</th>  
           <th>fourniture</th>  

           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

     while($row = mysqli_fetch_array($result))
     {
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["nom"] . '</td>  
           <td>' . $row["quantite"] . '</td>  
           <td>' . $row["fournisseur"] . '</td>  


             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierfourniture.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
     <i class="fas fa-edit"></i></a>
      </td>
  <td>

        <form action ="supprimerfourniture.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"> <i class="fas fa-trash"></i></button>
      </form>
      </td>
      </tr>  
      ';  
     }
     echo $output;
}
else
{
     echo 'Data Not Found';
}
?>