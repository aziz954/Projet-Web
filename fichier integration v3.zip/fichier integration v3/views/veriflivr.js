function verifier() 
{
    var errors ="";

    if(document.myform.nom.value=="")
    {

        errors += "a"; 

      }

    if(document.myform.prenom.value=="")
    {
        errors += "b";
    }

    if(document.myform.id.value.length < 8 || document.myform.id.value.length > 8 )
    {
        errors += "c";
    }
     if(document.myform.idliv.value=="")
    {
        errors += "d";
    }
    
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    }

