<?php
require('fpdf.php');
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('logo.png',10,6);
 $this->SetFont('Arial','B',13);
         $this->Cell(211,10,'MED LINE + ',0,0,'C');
        $this->Ln();
        $this->SetFont('Times','',12);
        $this->Cell(211,10,'DATA BASE OF DELEVERIES  ORDER BY DATE ',0,0,'C');
        $this->SetFont('Arial','B',15);
        $this->Cell(211,1,'Contact info:',0,0,'C');
     $this->Cell(211,1,'Email:Medline@gmail.com ',0,0,'C');
          $this->Cell(211,1,'Phone:+216 52 147 852 ',0,0,'C');
            $this->Cell(211,1,'Location:51, Avenue 10 Décembre 1948  ',0,0,'C');
        $this->Ln(20);

}

function footer(){


        $this->SetY(-60);
   $this->SetFont('Arial','B',15);
      
      $this->Cell(0,10,'Page '.$this->pageNo().'/{nb}',0,0,'C');


    }


   
    }
    $dbConnection = mysqli_connect('localhost', 'root', '', 'medline');

$query  = "SELECT * FROM facture";
$result = mysqli_query($dbConnection, $query);
$e=0;
$i=0;
$pdf = new PDF();
//header
$pdf->AddPage();
//foter page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',12);
if (mysqli_num_rows($result) > 0) {
$pdf->Cell(24,10,"Id ",1,0);
$pdf->Cell(40,10,"Reference",1,0);
$pdf->Cell(65,10,"id_com",1,0);
 $pdf->Cell(60,10,"Time",1,1);
 $pdf->Cell(60,10,"DATE",1,1); 

 while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
 $id = $row['id'];
 $ref = $row['mont'];
$id_com=$row['id_com'];
 $id_cl=$row['id_cl'];
$datef=$row['datef'];

if($e==0)
{
          
$pdf->Cell(24,10,"{$id} ",1,0);
$pdf->Cell(40,10,"{$mont} ",1,0);
$pdf->Cell(65,10,"{$id_com} ",1,0);
$pdf->Cell(60,10,"{$id_cl} ",1,1);
$pdf->Cell(60,10,"{$datef} ",1,1);
  
          }
  
  
  
      } }

$pdf->Output();
?>

