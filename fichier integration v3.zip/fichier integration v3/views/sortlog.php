<?php  
 //sort.php  
include "../core/loginC.php";

$log1C=new logC();
$listelog=$log1C->afficherlog();
$mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id FROM register");
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM register ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
      <th><a class="column_sort" id="usertype" data-order="'.$order.'" href="#">Usertypa</a></th>  
           <th><a class="column_sort" id="username" data-order="'.$order.'" href="#">Username</a></th>  
           <th><a class="column_sort" id="email" data-order="'.$order.'" href="#">Email</a></th> 
        <th><a class="column_sort" id="password" data-order="'.$order.'"href="#">Password</a></th> 
           <th><a class="column_sort" id="image" data-order="'.$order.'" href="#">image</a></th>  

              <td align="center" colspan="2">Actions</td> 
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["usertype"] . '</td>  
           <td>' . $row["username"] . '</td>  
           <td>' . $row["email"] . '</td> 
           <td>' . $row["password"] . '</td>  
           <td>' . $row["image"] . '</td>  

             <td align="center">
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="register_edit.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
  <i class="fas fa-edit"></i></a>
      </td>
  <td align="center">

        <form action ="supprimerlog.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  