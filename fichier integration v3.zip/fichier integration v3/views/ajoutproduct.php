<?PHP
include "../entities/producto.php";
include "../core/productoC.php";

if (!empty($_GET['id'])  and !empty($_GET['nom']) and !empty($_GET['quantite']) and !empty($_GET['image']) and !empty($_GET['prix'] )and !empty($_GET['description'])){
    $product1=new product($_GET['id'],$_GET['nom'],$_GET['quantite'],$_GET['image'],$_GET['prix'],$_GET['description']);

$product1C=new productC();
$product1C->ajouter($product1);
$sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'ADD', 'A delevery has been Added', 'unread', CURRENT_TIMESTAMP, 'gestionliv.php');";
		$db = config::getConnexion();

		try{
      
				        $req=$db->prepare($sql);

            $req->execute();
           
        }
          catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
header('Location: gestionproduct.php');
	
}
else{
	
	  
            header('Location: gestionproduct.php');
}
//*/

?>