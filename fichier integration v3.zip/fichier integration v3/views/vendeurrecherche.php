<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/vendeurC.php";
$ven1C=new venC();
$listeven=$ven1C->afficherven();
$mysqli=NEW MySQLi('localhost','root','','medline');

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script src="jquery-3.5.0.min.js"></script>
<script src="sweetalert2.all.min"></script>
<script language="javascript"type="text/javascript" src="verifvend.js"></script>
<script src="jquery-3.5.0.min.js"></script>
<script src="sweetalert2.all.min"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  

<?php
if(isset($_GET['message'])) {
  $message = $_GET['message'];
  echo $message;
}
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add VENDEURS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form  name="myform" action="ajoutven.php" method="GET" >

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="text" minlength="8" maxlength="8" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
                <label>Nom</label>
                <input type="text" name="nom" class="form-control" placeholder="Enter Nom">
            </div>
            <div class="form-group">
                <label>Prenom</label>
                <input type="text" name="prenom" class="form-control" placeholder="Enter Prenom">
            </div>
            <div class="form-group">
                <label>Num</label>
                <input type="times" name="num" class="form-control" placeholder="Enter Num">
            </div>
        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary" onclick="verifier()">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<form method="POST">
   <div class="input-group" >
              <input type="text" class="form-control bg-light border-0 small" name="search_text"id="search_text"placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">

 <div class="input-group-append">
                <button type="submit"name="submit"class="btn btn-primary2" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
</div>
</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">Vendeurs Profile 
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
            <i class="fas fa-plus-square"></i>
            </button>
             <button type="submit" name="registerbtn2"  class="btn btn-primary"onclick="myfun()"> <i class="fas fa-print"></i> </button></button>
                                   <script type="text/javascript">
                                    function myfun()
                                    {
                                      window.print();
                                    }
                                  </script>
                                                                </script>
   <style>
   display: block;
  height: 50px;
  width: 50px;   </style>

    </h6>
  </div>
</form>
  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

        <div id="result"></div>

  </div>
</div>

</div>
<!-- /.container-fluid -->
<style>

h5 {
    text-align: center;
}
 </style>
 <div class="d-sm-flex align-items-center justify-content-between mb-4">
 
  <h5>
    <a href="fpdf/vendpdf.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate pdf</a>
      </h5>

<h5>
   <a href="exel/indexv.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
        class="fas fa-download fa-sm text-white-50"></i> Generate exel</a>
    </h5>
</div>
<script>
$(document).ready(function(){
  load_data();
  function load_data(query)
  {
    $.ajax({
      url:"fetchv.php",
      method:"post",
      data:{query:query},
      success:function(data)
      {
        $('#result').html(data);
      }
    });
  }
  
  $('#search_text').keyup(function(){
    var search = $(this).val();
    if(search != '')
    {
      load_data(search);
    }
    else
    {
      load_data();      
    }
  });
});
</script>


<?php
include('includes/scripts.php');
include('includes/footer.php');
?>