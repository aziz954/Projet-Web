<?php  
 //sort.php  
include "../core/vendeurC.php";
$ven1C=new venC();
$listeven=$ven1C->afficherven();
$mysqli=NEW MySQLi('localhost','root','','medline');
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM vendeurs ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
           <th><a class="column_sort" id="nom" data-order="'.$order.'" href="#">Reference</a></th>  
           <th><a class="column_sort" id="prenom" data-order="'.$order.'" href="#">Adresse</a></th>  
           <th><a class="column_sort" id="num" data-order="'.$order.'" href="#">Time</a></th>  
           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["nom"] . '</td>  
           <td>' . $row["prenom"] . '</td>  
           <td>' . $row["num"] . '</td>  

             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="register_editven.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
     <i class="fas fa-edit"></i></a>
      </td>
  <td>

        <form action ="supprimerven.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"> </i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  