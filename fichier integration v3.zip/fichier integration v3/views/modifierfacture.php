
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/facture.php";
include "../core/factureC.php";
if (isset($_GET['id'])){
    $factureC=new factureC();
    $result=$factureC->recupererfacture($_GET['id']);
    foreach($result as $row){
        $id=$row['id'];
        $mont=$row['mont'];
        $id_com=$row['id_com'];
        $id_cl=$row['id_cl'];
        $datef=$row['datef'];
        $mysqli=NEW MySQLi('localhost','root','','medline');
$result=$mysqli->query("SELECT id_cl FROM client");
$result1=$mysqli->query("SELECT id as id_com FROM commande");
       
        ?>

<script language="javascript"type="text/javascript" src="veriffact.js"></script>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT BILLS </h6>
    </div>
    <div class="card-body">


<form name="myform" method="POST">

<input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="text" name="id" value="<?php echo $row['id']; ?>" class="form-control" placeholder="Enter id" readonly>
            </div>
            <div class="form-group">
                <label>Montant</label>
                <input type="text" name="mont" value="<?php echo $row['mont']; ?>" class="form-control" placeholder="Enter montant">
            </div>
            <div class="form-group">
                <label>ID commande</label>
                <select name="id_com"id="id_com">
                
<?php
while($rows = $result1->fetch_assoc())
{
$id_com=$rows['id_com'];
echo"<option value='$id_com'>$id_com</option>";
}
?>
                </select>
            </div >
            <div class="form-group">
                <label> ID client </label>
                <select name="id_cl">
                
<?php
while($rows = $result->fetch_assoc())
{
$id_cl=$rows['id_cl'];
echo"<option value='$id_cl'>$id_cl</option>";
}
?>
</select>
            </div>
            <div class="form-group">
                <label> Date </label>
                 <input type="date" name="datef"  value="<?php echo $row['datef']; ?>"class="form-control" placeholder="Enter Date">
            </div>
            <a href="gestionfacture.php" class="btn btn-danger" >CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary" onclick="verifier()">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])and !empty($_POST['mont'])and !empty($_POST['datef'])){
    
    $facture=new facture($_POST['id'],$_POST['mont'],$_POST['id_com'],$_POST['id_cl'],$_POST['datef']);
    $factureC->modifierfacture($facture,$_POST['edit_id']);

    $sql="INSERT INTO `notifications` (`id`, `name`, `type`, `message`, `status`, `date` , `lien`) VALUES (NULL, 'User/Admin', 'MODIFICATION', 'Bill has been Modified', 'unread', CURRENT_TIMESTAMP, 'gestionfacture.php');";
    $db = config::getConnexion();

    try{
  
                    $req=$db->prepare($sql);

        $req->execute();
       
    }
      catch (Exception $e){
        echo 'Erreur: '.$e->getMessage();
    }

    echo '<meta http-equiv="refresh" content="0; URL=gestionfacture.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
