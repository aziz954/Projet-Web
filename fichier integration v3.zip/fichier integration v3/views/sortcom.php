<?php  
 //sort.php  
include "../core/commandeC.php";
$CommandeC1C=new CommandeC();
$listeCommandeC=$CommandeC1C->affichercommandes();
$mysqli=NEW MySQLi('localhost','root','','medline');
 $connect = mysqli_connect("localhost","root","","medline");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  

 $query = "SELECT * FROM commande ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result = mysqli_query($connect, $query);  
 $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">ID</a></th>  
           <th><a class="column_sort" id="id_cl" data-order="'.$order.'" href="#">Id du client</a></th>  
           <th><a class="column_sort" id="q" data-order="'.$order.'" href="#">Quantite</a></th>  

           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

 while($row = mysqli_fetch_array($result))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["id_cl"] . '</td>  
           <td>' . $row["q"] . '</td>  

             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierc.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
     <i class="fas fa-edit"></i> </a>
      </td>
  <td>

        <form action ="supprimerc.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"> </i></button>
      </form>
      </td>
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>  