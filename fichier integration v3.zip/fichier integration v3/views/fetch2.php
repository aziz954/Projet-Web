<?php
$connect = mysqli_connect("localhost", "root", "", "medline");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM facture 
	WHERE id LIKE '%".$search."%'
	OR mont LIKE '%".$search."%' 
	OR id_com LIKE '%".$search."%' 
	OR id_cl LIKE '%".$search."%' 
	OR datef LIKE '%".$search."%'
	";
}
else
{
	$query = "
	SELECT * FROM facture ORDER BY id";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th>ID</th>  
           <th>Reference</th>  
           <th>id_comesse</th>  
           <th>Time</th>  
           <th>Date</th> 
           <td align="center" colspan="2">Actions</td>
      </tr>  
 ';  

	while($row = mysqli_fetch_array($result))
	{
	 $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["mont"] . '</td>  
           <td>' . $row["id_com"] . '</td>  
           <td>' . $row["id_cl"] . '</td>  
           <td>' . $row["datef"] . '</td> 
             <td>
       
          <input type="hidden" name ="edit_id2" value= ' . $row["id"] . '>

     <a href="modifierfacture.php?id= ' . $row["id"] . ' " class ="btn btn-primary ">
     <i class="fas fa-edit"></i></a>
      </td>
  <td>

        <form action ="supprimerfacture.php" method="POST">
<input type="hidden" name="id" value=' . $row["id"] . '>

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
      </form>
      </td>
      </tr>  
      ';  
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>