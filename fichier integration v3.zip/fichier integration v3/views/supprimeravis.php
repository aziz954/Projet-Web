<?PHP
include "../core/avisC.php";
$avisC=new avisC();
if (isset($_POST["id_cl"])){
  $factureC->supprimerAvis($_POST["id_cl"]);
  header('Location: afficheravisf.php');
}

?>