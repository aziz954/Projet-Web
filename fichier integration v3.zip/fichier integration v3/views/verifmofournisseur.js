function verifier() {
    var errors ="";
    if(document.myform.nom.value==""){
    errors += "a";
    }
    if(document.myform.prenom.value==""){
    errors += "b";
    }
    if(document.myform.tache.value==""){
    errors += "c";
    }
    if(errors!="") {
        document.getElementById('erreur').innerHTML = errors;
        return false;
    }
    }