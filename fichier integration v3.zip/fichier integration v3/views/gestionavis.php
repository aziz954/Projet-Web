<?php
session_start();
include('includes/header.php'); 
include('includes/navbar.php'); 
include "../core/avisC.php";
$avis1C=new avisC();
$listeavis=$avis1C->afficherAvis();
?>


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Defactureery</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <form action="ajouterAvis.php" method="GET">

        <div class="modal-body">

            <div class="form-group">
                <label> ID </label>
                <input type="text" name="id" class="form-control" placeholder="Enter Id">
            </div>
            <div class="form-group">
                <label>type</label>
                <input type="text" name="type" class="form-control" placeholder="Enter type">
            </div>
            <div class="form-group">
                <label>avis</label>
                <input type="text" name="avis" class="form-control" placeholder="Enter avis">
            </div>
            
               
        
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="registerbtn2"  class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">avis Profile 
            
    </h6>
  </div>

  <div class="card-body">
    <?php
    if(isset($_SESSION['success'])&& $_SESSION['success']!='')
    {
      echo '<h2 class ="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
  }
  if(isset($_SESSION['status'])&& $_SESSION['status']!='')
    {
      echo '<h2 class = "bg-danger text-white">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
  }


    ?>

    <div class="table-responsive">

      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th> ID_client </th>
            <th> type </th>
            <th>avis </th>
           
            <th>EDIT </th>
            <th>DELETE </th>
          </tr>
        </thead>
        <tbody>
     <?php
foreach($listeavis as $row){

 
  
    ?>
    <tr>
      <td><?php echo $row['id_client']; ?> </td>
      <td><?php echo $row['type']; ?> </td>
      <td><?php echo $row['avis']; ?> </td>
     
      <td>
       
          <input type="hidden" name ="edit_id3" value="<?php echo $row['id_client']; ?>">

     <a href="modifieravis.php?id=<?PHP echo $row['id']; ?>" class ="btn btn-primary "><i class="fas fa-edit"></i></a>
      </td>
      <td>
        <form action ="supprimeravis.php" method="POST">
<input type="hidden" name="id" value="<?php echo $row['id_client']; ?>">

        <button type="submit"name ="delete_btn2" class ="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
      </form>
      </td>
    </tr>
    <?php
  }

     ?>
          
        
        </tbody>
      </table>

    </div>
  </div>
</div>

</div>
  <div class="col-xl-4 col-lg-5">
              
               <!-- Donut Chart -->
            <div class="col-xl-4 col-lg-5">
              
                <!-- Card Header - Dropdown -->
                 <?php  
 $connect = mysqli_connect("localhost", "root", "", "medline");  
 $query = "SELECT type, count(*) as id_client FROM avis GROUP BY type";  
 $result = mysqli_query($connect, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Stat des fournisseurs</title>  
           <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['type', 'id_client'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["type"]."', ".$row["id_client"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Percentage ',  
                      //is3D:true,  
                      pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>  
      </head>  
      <body>  
           <br /><br />  
           <div style="width:900px;">  
                <h3 align="center">STAT DES Avis</h3>  
                <br />  
                <div id="piechart" style="width: 900px; height: 500px;"></div>  
           </div>  
      </body>  
 </html>  
                
             
            </div>
<!-- /.container-fluid -->

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>