<?php
session_start();
require_once('vendor/autoload.php');

$FBObject = new \Facebook\Facebook([
	'app_id' => '558064248479062',
	'app_secret' => '1d098106a358fe38107d3776cca55abc',
	'default_graph_version' => 'v2.10'
]);

$handler = $FBObject -> getRedirectLoginHelper();
?>