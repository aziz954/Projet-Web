<?PHP
include "../entities/ordonnance.php";
include "../core/ordonnanceC.php";

if (isset($_GET['ref']) and isset($_GET['idclient']) and isset($_GET['idmedicament'])  )
{
$ord1=new ord($_GET['ref'],$_GET['idclient'],$_GET['idmedicament']);

$ord1C=new ordC();
$ord1C->ajouter($ord1);
header('Location: gestionord.php');
	
}
else{
	
	  echo "not done";
            $_SESSION['status'] =  "Prescription is Not Added";
            header('Location: gestionord.php');
}
//*/

?>