<?PHP
include "../core/clientC.php";
$clientC=new clientC();
if (isset($_POST["id"])){
  $clientC->supprimerclient($_POST["id"]);
  header('Location: gestionclient.php');
}

?>