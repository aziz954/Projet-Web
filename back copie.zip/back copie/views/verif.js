function verifier() {

        var nom = document.getElementByID('nom').value;
    var prenom = document.getElementByID('prenom').value;
    var adresse = document.getElementByID('adresse').value;
    var num = document.getElementByID('num').value;
    var id = document.getElementByID('id').value;

    nom=false; prenom=false; adresse=false; num=false; id=false; alerte="";
    nom=false; prenom=false; adresse=false; num=false; id=false; alerte="";

    if(f.nom.value)
    {
     alerte += "Indiquer votre nom \n";  
    }
    else
    {
     nom = true;
    }
    if (f.prenom.value)
    {
     alerte += "Indiquer votre prenom \n";  
    }
    else
    {
    prenom = true;
    }
    if (f.adresse.value)
    {
     alerte += "Indiquer votre adresse \n";  
    }
    else
    {
    adresse = true;
    }
    if (f.num.value)
    {
     alerte += "Indiquer votre adresse \n";  
    }
    else
    {
    num = true;
    }
    if (f.id.value)
    {
     alerte += "Indiquer votre adresse \n";  
    }
    else
    {
    id = true;
    }
    if (nom==true && prenom==true && adresse==true && num==true && id==true)
    {
     return true;
    }
    else
    {
      alert(alerte);
      return false;
    }
    
    }
   

    