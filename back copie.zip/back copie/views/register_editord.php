
<?php
include('security.php');

include('includes/header.php'); 
include('includes/navbar.php'); 

include "../entities/ordonnance.php";
include "../core/ordonnanceC.php";
if (isset($_GET['ref'])){
    $ordC=new ordC();
    $result=$ordC->recupererord($_GET['ref']);
    foreach($result as $row){
        $ref=$row['ref'];
        $idclient=$row['idclient'];
        $idmedicament=$row['idmedicament'];
       
        ?>

<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">EDIT DE  </h6>
    </div>
    <div class="card-body">


<form method="POST">

<input type="hidden" name="edit_ref" value="<?php echo $row['ref']; ?>">

  <div class="form-group">
                <label> ID </label>
                 <input type="number" name="ref" value="<?php echo $row['ref']; ?>" class="form-control" placeholder="Enter ID" readonly>
            </div>
            <div class="form-group">
                <label>Id client</label>
                <input type="number" name="idclient" value="<?php echo $row['idclient']; ?>" class="form-control" placeholder="Enter ID CLIENT">
            </div>
            <div class="form-group">
                <label>idmedicamentuantité</label>
                <input type="number" name="idmedicament" value="<?php echo $row['idmedicament']; ?>"class="form-control" placeholder="Enter idmedicamentuantite">
            </div >
            
            <a href="gestionord.php" class="btn btn-danger">CANCEL </a>
            <button type="submit" name="updatebtn2"class ="btn btn-primary">Update</button>

</form>
       
               </div>
       
 <?PHP

   }

     }  
              
       
     if (isset($_POST['updatebtn2'])){
    
    $ord=new ord($_POST['ref'],$_POST['idclient'],$_POST['idmedicament']);
    $ordC->modifier($ord,$_POST['edit_ref']);


    echo '<meta http-equiv="refresh" content="0; URL=gestionord.php">';
}
?>

    </div>
</div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');

?>
