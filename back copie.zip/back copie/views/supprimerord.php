<?PHP
include "../core/ordonnanceC.php";
$ordC=new ordC();
if (isset($_POST["ref"]))
{
  $ordC->supprimerord($_POST["ref"]);
  header('Location: gestionord.php');
}

?>