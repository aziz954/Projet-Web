<?php
/**
 * 
 */
 

class ord
{
	
	private $ref;
	private $idclient;
	private $idmedicament;
	
	public function getref(){
		return $this->ref;

	}
	public function getidc()
	{
		return $this->idclient;

	}
	public function getidm()
	{
		return $this->idmedicament;

	}
	
	public function setref($ref)
	{

		$this->ref=$ref;
	}
	public function setidc($idclient)
	{

		$this->adr=$adr;
	}
	public function setidm($idmedicament)
	{

		$this->heure=$heure;
	}
	
	public function construct()
	{

		$this->ref=0;
		$this->idclient=0;
		$this->idmedicament=0;


	}
	public function __construct($ref,$idclient,$idmedicament)
	{
	
		$this->ref=$ref;
		$this->idclient=$idclient;
		$this->idmedicament=$idmedicament;
	}
	
}

?>


