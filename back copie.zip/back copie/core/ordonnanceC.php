<?PHP
include "../config.php";
class ordC {
function afficher ($ord)
	{
		echo "ref: ".$ord->getref()."<br>";
		echo "idclient: ".$ord->getidc()."<br>";
		echo "idmedicament: ".$ord->getidm()."<br>";
	}
	
	function ajouter($ord)
	{
		$sql="insert into ordonnance (ref,idclient,idmedicament) values (:ref,:idclient,:idmedicament)";
		$db = config::getConnexion();
		try
		{
        	$req=$db->prepare($sql);
        	$ref=$ord->getref();
        	$idclient=$ord->getidc();
        	$idmedicament=$ord->getidm();
        	
			$req->bindValue(':ref',$ref);
			$req->bindValue(':idclient',$idclient);
			$req->bindValue(':idmedicament',$idmedicament);
		
            $req->execute();
           
        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }
		
	}
	
	function afficherord()
	{
		//$sql="SElECT * From employe e inner join formationphp.employe a on e.cin= a.cin";
		$sql="SElECT * From ordonnance";
		$db = config::getConnexion();
		try
		{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }	
	}
	function supprimerord($ref){
		$sql="DELETE FROM ordonnance where ref= :ref";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':ref',$ref);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	function modifier($ord,$ref){
		$sql="UPDATE ordonnance SET ref=:ref,idclient=:idclient,idmedicament=:idmedicament WHERE ref=:ref";
		
		$db = config::getConnexion();
		//$db->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
try{		
       $req=$db->prepare($sql);
        	$ref=$ord->getref();
        	$idclient=$ord->getidc();
        	$idmedicament=$ord->getidm();
		$datas = array(':ref'=>$ref, ':idclient'=>$idclient,':idmedicament'=>$idmedicament);
	
		$req->bindValue(':ref',$ref);
			$req->bindValue(':idclient',$idclient);
			$req->bindValue(':idmedicament',$idmedicament);

		
            $s=$req->execute();
			
           // header('Location: index.php');
        }
        catch (Exception $e){
            echo " Erreur ! ".$e->getMessage();
   echo " Les datas : " ;
  print_r($datas);
        }
		
	}
	function recupererord($ref){
		$sql="SELECT * from ordonnance where ref=$ref";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
	
	function rechercherListeEmployes($ref){
		$sql="SELECT * from ordonnance where ref=$ref";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
}

?>
